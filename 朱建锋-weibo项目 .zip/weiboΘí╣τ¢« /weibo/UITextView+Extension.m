//
//  UITextView+Extension.m
//  weibo
//
//  Created by apple-jd37 on 15/11/20.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "UITextView+Extension.h"

@implementation UITextView (Extension)

- (void)insertAttributeText:(NSAttributedString *)text
{
    NSMutableAttributedString *attributeText = [[NSMutableAttributedString alloc] init];
    //拼接之前的文字（包括图片和普通文字）
    [attributeText appendAttributedString:self.attributedText];
    
    //拼接图片
    NSUInteger loc = self.selectedRange.location;
    //插入
//    [attributeText insertAttributedString:text atIndex:loc];
    //替换
    [attributeText replaceCharactersInRange:self.selectedRange withAttributedString:text];
    self.attributedText = attributeText;
    
    //移除光标到表情后面
    self.selectedRange = NSMakeRange(loc+1, 0);
}

@end
