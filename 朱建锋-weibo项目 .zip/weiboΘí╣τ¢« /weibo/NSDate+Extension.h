//
//  NSDate+Extension.h
//  weibo
//
//  Created by apple-jd37 on 15/11/12.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (Extension)

//判断是否是今年
- (BOOL)isThisYear;

//判断是否是昨天
- (BOOL)isYesterday;

//判断是否是今天
- (BOOL)isToday;


@end
