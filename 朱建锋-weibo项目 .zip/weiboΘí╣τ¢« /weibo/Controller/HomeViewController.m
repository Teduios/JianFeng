//
//  HomeViewController.m
//  我的微博项目
//
//  Created by apple-jd37 on 15/10/17.
//  Copyright (c) 2015年 apple-jd37. All rights reserved.
//

#import "HomeViewController.h"
#import "PullDownViewController.h"
#import "dropDownView.h"
#import "WBstatusFrame.h"
#import "Oauth_Account.h"
#import "OauthViewController.h"
#import "NewTitleButton.h"
#import "WBUserInfo.h"
#import "WBStatus.h"
#import "showImageViewController.h"
#import "WBStatusCell.h"
#import "QRcodeViewController.h"

@interface HomeViewController () <dropDownViewDelegate,UITableViewDataSource,UITableViewDelegate>
@property (nonatomic,strong) UIImageView  *littleimageView;
@property (nonatomic,strong) UIView  *markView;
@property (nonatomic,strong) UIView   *firstView;                  //第一套方案的view
@property (nonatomic,strong) UIImageView   *coverView;      //设置蒙板
@property (nonatomic,strong) UITableView  *tableView;         //表视图
@property (nonatomic,strong) UIButton  *titleButton;             //标题栏下拉按钮
@property (nonatomic,strong) PullDownViewController  *vc;   //自定义标题下拉类
@property (nonatomic,strong) NSMutableArray  *statusFrame; //总微博数组
@property (nonatomic) BOOL  isEnter;                                        //判断执行哪套方案
@property (nonatomic) NSInteger  UnreadCount;                      //记录未读的新微博数量
@property (nonatomic,strong) UIRefreshControl  *refreshControll;
@property (nonatomic,assign) NSInteger  imagesCount;
@property (nonatomic,strong) NSString  *imagePath;

@end

@implementation HomeViewController

- (UIRefreshControl *)refreshControll
{
    if (!_refreshControll) {
        _refreshControll = [[UIRefreshControl alloc] init];
        
    }
    return _refreshControll;
}
- (NSMutableArray *)statusFrame
{
    if (!_statusFrame) {
        _statusFrame = [NSMutableArray new];
    }
    return _statusFrame;
}
- (void)viewDidLoad {
    [super viewDidLoad];
   
}

/**
 *  初始化布局：2套方案
 */
- (instancetype)init
{
    if (self = [super init]) {
        [[UINavigationBar appearance] setTitleTextAttributes:@{NSForegroundColorAttributeName: [UIColor blackColor],NSFontAttributeName:[UIFont fontWithName:@"Baskerville" size:14.0]}];
        self.navigationItem.title = @"微博";
        
        Oauth_Account *acount = [NSKeyedUnarchiver unarchiveObjectWithFile:AccountPath];
         NSLog(@"%ld",acount.recordMark);
        if (acount.recordMark == 1) {
            _isEnter = NO;
        }else{
            _isEnter = YES;
        }
        if (_isEnter == YES) {
            [self show];
        }else{
            [self showSecondView];
        }
        [self KeyframeAnimation];
    }
    return self;
}

/**
 *  显示第一种view
 */
- (void)show{
     NSLog(@"这是第一个");
    //定义第一个初始未登陆时的view
    UIView *firstView = [[UIView alloc] init];
    firstView.frame = CGRectMake(0, 0, viewWidth, viewHeight - 49-64);
    self.firstView = firstView;
    //设置父Dview
    UIView *Dview = [[UIView alloc] initWithFrame:CGRectMake(0, 32, viewWidth, viewHeight*0.35)];
    
    //设置转圈的imageView
    UIImageView *littleImageView = [[UIImageView alloc] initWithFrame:CGRectMake(2.6/10.0*viewWidth, 0.022*viewHeight,1/2.0*viewWidth, 1/2.0*viewWidth)];
    littleImageView.image = [UIImage imageNamed:@"visitordiscover_feed_image_smallicon"];
    littleImageView.alpha = 1;
    self.littleimageView = littleImageView;
    [Dview addSubview:littleImageView];
 
    //设置动画
    
    [NSTimer scheduledTimerWithTimeInterval:0.05 target:self selector:@selector(rotation:) userInfo:nil repeats:YES];
    
    //设置主页图片的imageView
    UIImageView *homeImageView = [[UIImageView alloc] initWithFrame:CGRectMake(3/8.0*viewWidth, 0.5*viewHeight, 1/4.0*viewWidth+10, 1/4.0*viewWidth+10)];
    
    
    homeImageView.backgroundColor = [UIColor colorWithRed:240/255.0 green:240/255.0 blue:240/255.0 alpha:1];
    homeImageView.centerY = Dview.centerY;
    homeImageView.image = [UIImage imageNamed:@"visitordiscover_feed_image_house"];
    homeImageView.alpha = 1;

    [Dview addSubview:homeImageView];
    self.markView = Dview;
    [firstView addSubview:Dview];
    
    //设置文本Label
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0.1*viewWidth, textStartHeight, 0.8*viewWidth, 60)];
    label.textAlignment = NSTextAlignmentCenter;
    label.numberOfLines = 0;
    label.text = @"当你关注一些人以后，他们发布的最新的消息会显示在这里";
    label.textColor = [UIColor blackColor];
    label.alpha = 0.5;
    label.font = [UIFont systemFontOfSize:14];
    [firstView addSubview:label];
    
    //设置两个按钮
    UIButton *registerButton = [[UIButton alloc] initWithFrame:CGRectMake(1/12.0*viewWidth, buttonStartHeight, buttonWidth, buttonHeight)];

    [registerButton setTintAdjustmentMode:UIViewTintAdjustmentModeNormal];
    [registerButton setTitle:@"注册" forState:UIControlStateNormal];
    [registerButton setBackgroundColor:[UIColor whiteColor]] ;
    [registerButton addTarget:self action:@selector(Login) forControlEvents:UIControlEventTouchUpInside];
    [registerButton setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal ] ;
    
    UIButton *registerButton2 = [[UIButton alloc] initWithFrame:CGRectMake(1/12.0*viewWidth+0.4*viewWidth+buttonMargin, buttonStartHeight, buttonWidth, buttonHeight)];
    [registerButton2 setTintAdjustmentMode:UIViewTintAdjustmentModeNormal];
    registerButton2.backgroundColor = [UIColor whiteColor];
    [registerButton2 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal ] ;
    [registerButton2 addTarget:self action:@selector(Login) forControlEvents:UIControlEventTouchUpInside];
    [registerButton2 setTitle:@"登陆" forState:UIControlStateNormal];
    [firstView addSubview:registerButton];
    [firstView addSubview:registerButton2];
    [self.view addSubview:firstView];
   
}

/**
 *  点击登陆后跳转注册界面
 */
- (void)Login
{ 
    OauthViewController *vc = [OauthViewController new];
    [self presentViewController:vc animated:YES completion:nil];
}

/**
 *  得到用户昵称、设置导航栏标题和左右按钮
 */
- (void)getUserName
{
    NSString *url = @"https://api.weibo.com/2/users/show.json";
    //把数据模型从沙盒中拿到
    Oauth_Account *acount =[Oauth_Account acounted];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *parameter = [NSMutableDictionary dictionary];
    parameter[@"access_token"] = acount.access_token;
    parameter[@"uid"] = acount.uid;
    
    [manager GET:url parameters:parameter success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {

        [self.coverView removeFromSuperview];
        [MBProgressHUD showMessage:@"正在加载数据"];

        dispatch_async(dispatch_get_main_queue(), ^{
            //显示标题按钮
            NewTitleButton *titleButton = [[NewTitleButton alloc] init];
            self.titleButton = titleButton;
            [titleButton setTitle:responseObject[@"name"] forState:UIControlStateNormal];
            titleButton.titleLabel.x = titleButton.imageView.x;
            titleButton.imageView.x = CGRectGetMaxX(titleButton.titleLabel.frame);
           
             NSLog(@"%@",responseObject[@"name"]);
            [titleButton addTarget:self action:@selector(clickTitle:) forControlEvents:UIControlEventTouchUpInside];
          
            self.navigationItem.titleView =titleButton;
            
            self.navigationItem.leftBarButtonItem = [UIBarButtonItem itemWIthTarget:self action:@selector(searchFriends) image:@"navigationbar_friendsearch" highImage:@"navigationbar_friendsearch_highlighted"];
            self.navigationItem.rightBarButtonItem = [UIBarButtonItem itemWIthTarget:self action:@selector(scanner) image:@"navigationbar_pop" highImage:@"navigationbar_pop_highlighted"];

             NSLog(@"%f",self.navigationItem.titleView.width);
             NSLog(@"%f",self.navigationItem.leftBarButtonItem.width);
            
            WBUserInfo *user = [WBUserInfo objectWithKeyValues:responseObject];
            acount.userName = user.name;
            
            [Oauth_Account saveAcount:acount];
            [MBProgressHUD hideHUD];

        });
    } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        ZJFLog(@"请求失败 %@",error);
    }];
}

/**
 * 表格下拉刷新
 */
- (void)refreshTableView
{
//    UIRefreshControl *refresh = [[UIRefreshControl alloc] init];
    [self.refreshControll addTarget:self action:@selector(refreshActivity:) forControlEvents:UIControlEventValueChanged];
//     self.refreshControll.attributedTitle = [[NSAttributedString alloc] initWithString:@"微博君正在拼命努力加载中啊"];
     self.refreshControll.tintColor = [UIColor purpleColor];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"MMMd, h:mm a"];
    NSString *lastUpdated = [NSString stringWithFormat:@"上次更新时间:%@",[formatter stringFromDate:[NSDate date]]];
      self.refreshControll.attributedTitle = [[NSAttributedString alloc] initWithString:lastUpdated];
    [self.tableView addSubview:self.refreshControll];
    
    [self.refreshControll beginRefreshing];
    [self refreshActivity2:self.refreshControll];
}

/**
 * 点击tableBar刷新自己
 */
/*
- (void)refreshData
{
     NSLog(@"refreshData");
    
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        
        //访问新数据路径
        NSString *url = @"https://api.weibo.com/2/statuses/friends_timeline.json";
        Oauth_Account *acount = [Oauth_Account acounted];
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        NSMutableDictionary *parameter = [NSMutableDictionary dictionary];
        parameter[@"access_token"] = acount.access_token;
        parameter[@"count"] = @"99";
        //拿到已接收到的第一条微博
        WBStatus *status = self.allInfo.firstObject;
        if (status) {
            parameter[@"since_id"] = status.idstr;
        }
        [manager GET:url parameters:parameter success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
            NSArray *arr = [WBStatus objectArrayWithKeyValuesArray:responseObject[@"statuses"]];
            
            NSInteger newInfoCount = arr.count;
            
            NSRange range = NSMakeRange(0, newInfoCount);
            NSIndexSet *set = [NSIndexSet indexSetWithIndexesInRange:range];
            [self.allInfo insertObjects:arr atIndexes:set];
            //刷新表格
            [self.tableView reloadData];
            //停止刷新
            [self.tableView.header endRefreshing];
             NSLog(@"self.tableView.header endRefreshing");
        } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
            ZJFLog(@"刷新数据失败 %@",error);
            
        }];

    }];
   
}
 */

/**
 *  一开始第一次刷新做的事情
 */
- (void)refreshActivity2:(UIRefreshControl *)control
{
    //访问新数据路径
    NSString *url = @"https://api.weibo.com/2/statuses/friends_timeline.json";
    Oauth_Account *acount = [Oauth_Account acounted];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *parameter = [NSMutableDictionary dictionary];
    parameter[@"access_token"] = acount.access_token;
//    parameter[@"count"] = @"99";
    //拿到已接收到的第一条微博
    WBstatusFrame *status = [self.statusFrame firstObject];
    if (status) {
        parameter[@"since_id"] = status.statues.idstr;
    }
    [manager GET:url parameters:parameter success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        NSArray *arr = [WBStatus objectArrayWithKeyValuesArray:responseObject[@"statuses"]];
        
        //将“微博字典”数组转为“微博模型”数组
        NSArray *newsFrame = [self statusFrameesWithStatuses:arr];
        
        NSRange range = NSMakeRange(0, newsFrame.count);
        NSIndexSet *set = [NSIndexSet indexSetWithIndexesInRange:range];
        [self.statusFrame insertObjects:newsFrame atIndexes:set];
        //刷新表格
        [self.tableView reloadData];
        //停止刷新
        [control endRefreshing];
        [self setRefreshView:arr.count];


    } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        ZJFLog(@"刷新数据失败 %@",error);
        //停止刷新
        [control endRefreshing];
    }];
}

/**
 *  刷新的时做的事情
 *
 *  @param control 传入的刷新控件
 */
- (void)refreshActivity:(UIRefreshControl *)control
{
    //访问新数据路径
    NSString *url = @"https://api.weibo.com/2/statuses/friends_timeline.json";
    Oauth_Account *acount = [Oauth_Account acounted];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *parameter = [NSMutableDictionary dictionary];
    parameter[@"access_token"] = acount.access_token;
//    parameter[@"count"] = @"50";
    //拿到已接收到的第一条微博
    WBstatusFrame *status = self.statusFrame.firstObject;
    if (status) {
        parameter[@"since_id"] = status.statues.idstr;
        
    }
    [manager GET:url parameters:parameter success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        NSArray *arr = [WBStatus objectArrayWithKeyValuesArray:responseObject[@"statuses"]];
        //将“微博字典”数组转为“微博模型”数组
        NSArray *newsFrame = [self statusFrameesWithStatuses:arr];
        
        NSRange range = NSMakeRange(0, newsFrame.count);
        NSIndexSet *set = [NSIndexSet indexSetWithIndexesInRange:range];
        [self.statusFrame insertObjects:newsFrame atIndexes:set];
        //刷新表格
        [self.tableView reloadData];
        //停止刷新
        [control endRefreshing];
        [self setRefreshView:arr.count];
        
    } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        ZJFLog(@"刷新数据失败 %@",error);
        //停止刷新
        [control endRefreshing];
    }];
}

/**
 *  通过传参来显示微博刷新时的界面
 *
 *  @param count 新的微博数量
 */
- (void)setRefreshView:(NSInteger)count
{
    // 刷新成功(清空图标数字)
    self.tabBarItem.badgeValue = nil;
    [UIApplication sharedApplication].applicationIconBadgeNumber = 0;

    //建立一个新的视图
    UILabel *label = [[UILabel alloc] init];
    label.size = CGSizeMake(viewWidth, 35);
    label.y = 64-label.height;
    label.textColor = [UIColor whiteColor];
    label.font = [UIFont systemFontOfSize:16];
    label.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"timeline_new_status_background"]];
    label.textAlignment = NSTextAlignmentCenter;
    if (count == 0) {
        self.tabBarItem.badgeValue = nil;
        label.text = [NSString stringWithFormat:@"你没有新数据哦～～"];
    }else{
        label.text = [NSString stringWithFormat:@"加载了最新的%ld条新数据哟",count];
         NSLog(@"%ld",count);
        self.tabBarItem.badgeValue = nil;
    }
    NSTimeInterval duration = 1.0f;
    [UIView animateWithDuration:duration animations:^{
        label.transform = CGAffineTransformMakeTranslation(0, label.height);
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:duration delay:1.0 options:UIViewAnimationOptionCurveLinear animations:^{
            label.transform = CGAffineTransformIdentity;
        } completion:^(BOOL finished) {
            //把label删除
            [label removeFromSuperview];
        }];
    }];
    
    [self.navigationController.view insertSubview:label belowSubview:self.navigationController.navigationBar];
}

/**
 *  得到用户信息
 */
/*
- (void)getUserInfo
{
    NSString *url = @"https://api.weibo.com/2/statuses/friends_timeline.json";
    Oauth_Account *acount = [Oauth_Account acounted];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *parameter = [NSMutableDictionary dictionary];
    parameter[@"access_token"] = acount.access_token;
    
    [manager GET:url parameters:parameter success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        self.allInfo = [WBStatus objectArrayWithKeyValuesArray:responseObject[@"statuses"] ];
        
        [self.tableView reloadData];
    } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
}
 */

/**
 *  点击标题下拉后执行
 *
 *  @param titleButton 传入自己，用来方便定位
 */
- (void)clickTitle:(UIButton *)titleButton
{
    dropDownView *dropdown = [dropDownView view];
    dropdown.delegate = self;
    //设置内容
    PullDownViewController *vc = [[PullDownViewController alloc] init];
    vc.view.height = 300;
    vc.view.width = 150;
    dropdown.contentController = vc;
    //显示
    [dropdown showFrom:titleButton];

}

- (void)dropdownMenuDidDismiss:(dropDownView *)view
{
    self.titleButton.selected = NO;
}

- (void)dropdownMenuDidShow:(dropDownView *)view
{
    self.titleButton.selected = YES;
}

/**
 *  显示第二种view
 */
- (void)showSecondView
{
    [self.firstView removeFromSuperview];
    NSLog(@"%@",self.firstView);
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, viewWidth, viewHeight - 49-64)];
    self.tableView = tableView;
    tableView.dataSource = self;
    tableView.delegate = self;
    tableView.backgroundColor = SetColor(211, 211, 211);
    
    [self.view addSubview:tableView];
    //创建未开始数据加载时的蒙板
    UIWindow *window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.coverView = [[UIImageView alloc] initWithFrame:window.bounds];
     NSLog(@"%@",NSStringFromCGRect(window.bounds));
     NSLog(@"aaaaaaaaaaaaa%@",NSStringFromCGRect([[UIScreen mainScreen] bounds]));
//        self.coverView.image = [UIImage imageNamed:@"popover_background_selected"];
    self.coverView.backgroundColor =SetColor(123, 123, 123);
    self.coverView.alpha = 0.4;
    [window addSubview:self.coverView];

//    tableView.backgroundColor = [UIColor yellowColor];
    //获得用户昵称
     [self getUserName];
//     [self getUserInfo];
    //表格下拉刷新
     [self refreshTableView];
    //显示表尾
    [self refreshFromFooter];
    //设置定时器
    [self getTimer];
    //接收点击图片的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showImage:) name:@"didClickImage" object:nil];
}

- (void)showImage:(NSNotification *)notification
{
    NSString *image = notification.userInfo[@"images"];
    NSArray *imageArr = notification.userInfo[@"imagesArr"];
    self.imagePath = image;
    self.imagesCount = imageArr.count;
    
    showImageViewController *imageVC = [[showImageViewController alloc] init];
    imageVC.imagePath = image;
    [self.navigationController pushViewController:imageVC animated:YES];
}


/**
 *  获得计时器
 */
- (void)getTimer
{
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:60
 target:self selector:@selector(showUnReadCount) userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:timer forMode:NSRunLoopCommonModes];
}

/**
 *  显示未读微博计数
 */
- (void)showUnReadCount
{
    NSString *url = @"https://rm.api.weibo.com/2/remind/unread_count.json";
    Oauth_Account *acount = [Oauth_Account acounted];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *parameter = [NSMutableDictionary dictionary];
    parameter[@"access_token"] = acount.access_token;
    parameter[@"uid"] = acount.uid;
    
    [manager GET:url parameters:parameter success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        NSString *unReadCount = [responseObject[@"status"] description];
        float version = [[[UIDevice currentDevice] systemVersion] floatValue];
        
        if ([unReadCount isEqualToString:@"0"]) {
            self.tabBarItem.badgeValue = nil;
            UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeBadge categories:nil];
            [[UIApplication sharedApplication] registerUserNotificationSettings:settings];
            [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
        }else{
            self.tabBarItem.badgeValue = unReadCount;
            self.UnreadCount = unReadCount.integerValue;
            
            if (version >= 8.0) {
                UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeBadge categories:nil];
                [[UIApplication sharedApplication] registerUserNotificationSettings:settings];
                [UIApplication sharedApplication].applicationIconBadgeNumber = unReadCount.intValue;
            }
            
        }
    } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        ZJFLog(@"获得最新未读数据失败-%@",error);
    }];
}

/**
 *   设置表尾视图
 */
- (void)refreshFromFooter
{
   self.tableView.footer =[MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        //定义路径
        NSString *url = @"https://api.weibo.com/2/statuses/friends_timeline.json";
        Oauth_Account *acount = [Oauth_Account acounted];
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        NSMutableDictionary *parameter = [NSMutableDictionary dictionary];
        parameter[@"access_token"] =acount.access_token;
        WBstatusFrame *status = self.statusFrame.lastObject;
        if (status) {
            long long maxId = status.statues.idstr.longLongValue-1;
            parameter[@"max_id"] = @(maxId);
//            parameter[@"count"] = @"99";
        }
        
        [manager GET:url parameters:parameter success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
            NSArray *newStatus = [WBStatus objectArrayWithKeyValuesArray:responseObject[@"statuses"]];
            //将“微博字典”数组转为“微博模型”数组
            NSArray *newsFrame = [self statusFrameesWithStatuses:newStatus];
            //把新加载的数据添加在总数组的最后
            [self.statusFrame addObjectsFromArray:newsFrame];
            [self.tableView reloadData];
            //            [footerView didLoadWBInfo];
            [self.tableView.footer endRefreshing];
        } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
            ZJFLog(@"表尾显示数据失败-%@",error);
        }];
    }];
}

#pragma mark - UITableViewDelegate
/**
 *  表格总行数
 */
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.statusFrame.count;
}

/**
 *  表格每行的样式
 */
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    WBStatusCell *cell = [WBStatusCell cellWithTableView:tableView];
    cell.statusFrame = self.statusFrame[indexPath.row];

//    WBStatus *status = self.statusFrame[indexPath.row];
//    WBUserInfo *userInfo = status.user;
//    cell.textLabel.text = status.text;
//    cell.detailTextLabel.text = userInfo.name;
//    UIImage *image = [UIImage imageNamed:@"avatar_default_small"];
//    [cell.imageView sd_setImageWithURL:[NSURL URLWithString:userInfo.profile_image_url] placeholderImage:image];
    
    return cell;
}

/**
 *  自动化设置行高，ios7新加入的协议，自动计算高度
 */
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    WBstatusFrame *frame = self.statusFrame[indexPath.row];
    return frame.cellHeight;
}


/**
 *  关键帧动画
 */
- (void)KeyframeAnimation
{
    CAKeyframeAnimation *animation = [CAKeyframeAnimation animation];
    animation.keyPath = @"transform.scale";
    animation.values = @[@1.1,@1.2,@1.3,@1.4,@1.5,@1.6,@1.7,@1.6,@1.5,@1.4,@1.3,@1.2,@1.1,@1.0];
    animation.duration = 1.0;
    animation.removedOnCompletion = NO;
    animation.fillMode = kCAFillModeForwards;
    [self.markView.layer addAnimation:animation forKey:nil];
}

/**
 *  旋转动画
 */
- (void)rotation:(NSTimer *)timer
{
    self.littleimageView.layer.transform = CATransform3DRotate(self.littleimageView.layer.transform,angleToRadian(0.5), 0, 0, 1);
}

/**
 *  点击导航栏左上角的按钮触发的动作
 */
- (void)searchFriends
{
     NSLog(@"1111");
}

/**
 *  点击导航栏右上角的按钮触发的动作
 */
- (void)scanner
{
    QRcodeViewController *vc = [[QRcodeViewController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}

/**
 *  将WBStatus模型转换为statusFrame
 */
- (NSArray *)statusFrameesWithStatuses:(NSArray *)statuses
{
    NSMutableArray *frames = [NSMutableArray array];
    for (WBStatus *status in statuses) {
        WBstatusFrame *fram = [[WBstatusFrame alloc] init];
        fram.statues = status;
        [frames addObject:fram];
    }
    return frames;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}





@end





