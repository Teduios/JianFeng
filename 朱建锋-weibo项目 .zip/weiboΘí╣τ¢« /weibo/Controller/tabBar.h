//
//  tabBar.h
//  我的微博项目
//
//  Created by apple-jd37 on 15/10/21.
//  Copyright (c) 2015年 apple-jd37. All rights reserved.
//

#import <UIKit/UIKit.h>
@class tabBar;

@protocol tabBarDelegate <UITabBarDelegate>

- (void)tabBarDidClickPlusButton;

@end

@interface tabBar : UITabBar

@property (nonatomic,weak)id <tabBarDelegate>delegate;

@end


/*
#import <UIKit/UIKit.h>
@interface TabbarRootViewController : UITabBarController<UITabBarControllerDelegate>
@end


#import "TabbarRootViewController.h"
#import "NoticeTableViewController.h"
@implementation TabbarRootViewController
-(void)viewDidLoad
{    [super viewDidLoad];
    self.delegate=self;
}
-(void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController
{    if (viewController.tabBarItem.tag==2)
    {        UINavigationController *navigation =(UINavigationController *)viewController;
        NoticeTableViewController *notice=(NoticeTableViewController *)navigation.topViewController;
        [notice refreshData];
    }
}@end
 */


