//
//  tabBar.m
//  我的微博项目
//
//  Created by apple-jd37 on 15/10/21.
//  Copyright (c) 2015年 apple-jd37. All rights reserved.
//

#import "tabBar.h"
#import "UIView+Extension.h"
#define button_Width 40
#define button_Height 40


@interface tabBar ()

@property (nonatomic ,strong)UIButton *plusBtn;

@end

@implementation tabBar

@synthesize delegate = _delegate;

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // 3.添加一个按钮到 tabbar 中
        UIButton *plusBtn = [[UIButton alloc]init];
        [plusBtn setBackgroundImage:[UIImage imageNamed:@"tabbar_compose_button"] forState:UIControlStateNormal];
        [plusBtn setBackgroundImage:[UIImage imageNamed:@"tabbar_compose_button_highlighted"] forState:UIControlStateHighlighted];
        [plusBtn setImage:[UIImage imageNamed:@"tabbar_compose_icon_add_highlighted"] forState:UIControlStateNormal];
        [plusBtn setImage:[UIImage imageNamed:@"tabbar_compose_icon_add_highlighted"] forState:UIControlStateHighlighted];
        plusBtn.size = plusBtn.currentBackgroundImage.size;
        [plusBtn addTarget:self action:@selector(plusClick) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:plusBtn];
        self.plusBtn = plusBtn;
    }
    return self;
}

- (void)plusClick
{
    // 通知代理，预防性措施
    if ([self.delegate respondsToSelector:@selector(tabBarDidClickPlusButton)]) {
        [self.delegate tabBarDidClickPlusButton];
    }
}

- (void)layoutSubviews {
    /* [super layoutSubviews] 一定要调用 因为 tabbar 的背景图片和阴影还需要系统来设置 */
    [super layoutSubviews];
    // 1.设置加号按钮的位置
    self.plusBtn.centerX = self.width * 0.5;
    self.plusBtn.centerY = self.height * 0.5;
    
    // 2.设置其它 tabbarButton 的位置和尺寸
    CGFloat tabbarButtonW = self.width / 5;
    CGFloat tabbarButtonIndex = 0;
    for (UIView *child in self.subviews) {
        Class class = NSClassFromString(@"UITabBarButton");
        if ([child isKindOfClass:class]) {
            // 设置宽度
            child.width = tabbarButtonW;
            // 设置 x
            child.x = tabbarButtonIndex * tabbarButtonW;
            
            // 增加索引
            tabbarButtonIndex++;
            if (tabbarButtonIndex == 2) {
                // 如果索引是2 就在增加一次索引 避免添加的按钮被覆盖住
                tabbarButtonIndex++;
            }
        }
    }
    
    //    int count = self.subviews.count;
    //    for (int i = 0; i<count; i++) {
    //        UIView *child = self.subviews[i];
    //
    //        Class class = NSClassFromString(@"UITabBarButton");
    //        if ([child isKindOfClass:class]) {
    //            // 设置宽度
    //            child.width = tabbarButtonW;
    //            // 设置 x
    //            child.x = tabbarButtonIndex * tabbarButtonW;
    //
    //            // 增加索引
    //            tabbarButtonIndex++;
    //            if (tabbarButtonIndex == 2) {
    //                // 如果索引是2 就在增加一次索引 避免添加的按钮被覆盖住
    //                tabbarButtonIndex++;
    //            }
    //        }
    //    }
}
@end
