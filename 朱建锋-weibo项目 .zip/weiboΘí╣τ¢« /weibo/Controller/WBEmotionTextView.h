//
//  WBEmotionTextView.h
//  weibo
//
//  Created by apple-jd37 on 15/11/20.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "WBTextView.h"

@class WBEmotion;
@interface WBEmotionTextView : WBTextView


- (void)insertEmotion:(WBEmotion *)emotion;

- (NSString *)fullText;

@end
