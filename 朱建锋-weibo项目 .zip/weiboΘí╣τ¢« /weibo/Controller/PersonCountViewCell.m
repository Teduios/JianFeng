//
//  PersonCountViewCell.m
//  weibo
//
//  Created by apple-jd37 on 15/11/24.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "PersonCountViewCell.h"
#import "PersonMessage.h"

@implementation PersonCountViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.backgroundColor = [UIColor clearColor];
        PersonMessage *message = [PersonMessage acounted];
        
        UIView *contentView = [[UIView alloc] init];
        contentView.frame = CGRectMake(0, 0, self.width, 40);
        CGFloat btnW = self.width/3;
        UIButton *statusBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, btnW, 40)];

        [statusBtn setBackgroundImage:[UIImage imageNamed:@"timeline_group_visible_button_background"] forState:UIControlStateNormal];
        [statusBtn setTitleColor:[UIColor purpleColor] forState:UIControlStateNormal];
        statusBtn.titleLabel.font = [UIFont fontWithName:@"Baskerville" size:16];
        [statusBtn setTitle:[NSString stringWithFormat:@"微博%d",message.statuses_count] forState:UIControlStateNormal];
        [contentView addSubview:statusBtn];
        
        UIButton *friendsBtn = [[UIButton alloc] initWithFrame:CGRectMake(btnW, 0, btnW, 40)];
        
        [friendsBtn setTitle:[NSString stringWithFormat:@"关注%d",message.friends_count] forState:UIControlStateNormal];
         [friendsBtn setBackgroundImage:[UIImage imageNamed:@"timeline_group_visible_button_background"] forState:UIControlStateNormal];
        friendsBtn.titleLabel.font = [UIFont fontWithName:@"Baskerville" size:16];
        [friendsBtn setTitleColor:[UIColor purpleColor] forState:UIControlStateNormal];
        [contentView addSubview:friendsBtn];
        
        UIButton *followsBtn = [[UIButton alloc] initWithFrame:CGRectMake(2*btnW, 0, btnW, 40)];
        [followsBtn setBackgroundImage:[UIImage imageNamed:@"timeline_group_visible_button_background"] forState:UIControlStateNormal];
        followsBtn.titleLabel.font = [UIFont fontWithName:@"Baskerville" size:16];
        [followsBtn setTitleColor:[UIColor purpleColor] forState:UIControlStateNormal];
        [followsBtn setTitle:[NSString stringWithFormat:@"粉丝%d",message.followers_count] forState:UIControlStateNormal];
        [contentView addSubview:followsBtn];
        
        [self addSubview:contentView];
        
    }
    return self;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
