//
//  WBStatuPhoto.m
//  weibo
//
//  Created by apple-jd37 on 15/11/14.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "WBStatuPhoto.h"
#import "WBPhoto.h"
#import "UIImageView+WebCache.h"

@interface WBStatuPhoto ()  
@property (nonatomic,weak) UIImageView  *gifView;

@end

@implementation WBStatuPhoto
- (UIImageView *)gifView
{
    if (!_gifView) {
        UIImage *image = [UIImage imageNamed:@"timeline_image_gif"];
        UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
        [self addSubview:imageView];
        self.gifView = imageView;
    }
    return _gifView;
}
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        
    }
    return self;
}


- (void)setPhoto:(WBPhoto *)photo
{
    _photo = photo;
     [self sd_setImageWithURL:[NSURL URLWithString:photo.thumbnail_pic] placeholderImage:[UIImage imageNamed:@"timeline_image_placeholder"]];
    
    self.userInteractionEnabled = YES;
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickImage:)];
    [self addGestureRecognizer:singleTap];
    
    //无论是大小写都找“gif”
    self.gifView.hidden = ![photo.thumbnail_pic.lowercaseString hasSuffix:@"gif"];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    //布局
    self.gifView.x = self.width-self.gifView.width;
    self.gifView.y = self.height- self.gifView.height;
}

- (void)clickImage:(UITapGestureRecognizer *)gr
{
    NSMutableDictionary *userInfo = [NSMutableDictionary dictionary];
    userInfo[@"images"] = self.photo.thumbnail_pic;
    userInfo[@"imagesArr"] = self.imageArr;
    [[NSNotificationCenter defaultCenter] postNotificationName:@"didClickImage" object:nil userInfo:userInfo];
    
}

@end
