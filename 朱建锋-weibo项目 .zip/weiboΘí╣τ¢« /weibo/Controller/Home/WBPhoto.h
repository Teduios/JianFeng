//
//  WBPhoto.h
//  weibo
//
//  Created by apple-jd37 on 15/11/9.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WBPhoto : NSObject

//缩略图地址
@property (nonatomic,copy) NSString  *thumbnail_pic;

@end
