//
//  WBtoolBar.h
//  weibo
//
//  Created by apple-jd37 on 15/11/11.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import <UIKit/UIKit.h>

@class WBStatus;
@interface WBtoolBar : UIView

+ (instancetype)toolBar;

@property (nonatomic,strong) WBStatus  *status;

@end
