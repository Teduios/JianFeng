//
//  WBIconPhoto.m
//  weibo
//
//  Created by apple-jd37 on 15/11/14.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "WBIconPhoto.h"
#import "WBUserInfo.h"
#import "UIImageView+WebCache.h"

@interface WBIconPhoto ()
@property (nonatomic,weak) UIImageView  *verifiedView;

@end

@implementation WBIconPhoto
- (UIImageView *)verifiedView
{
    if (!_verifiedView) {
        UIImageView *verifiedView = [[UIImageView alloc] init];
        [self addSubview:verifiedView];
        self.verifiedView = verifiedView;
    }
    return _verifiedView;
}
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        
    }
    return self;
}

- (void)setUser:(WBUserInfo *)user
{
    _user = user;
    [self sd_setImageWithURL:[NSURL URLWithString:user.profile_image_url] placeholderImage:[UIImage imageNamed:@"avatar_default_small"]];
    //设置
    switch (user.verified_type) {
        case WBUserVerifiedTypePersonal:
        {
            self.verifiedView.hidden=NO;
            self.verifiedView.image = [UIImage imageNamed:@"avatar_vip"];
            break;
        }
        case WBUserVerifiedTypeOrgEnterprice:
        case WBUserVerifiedTypeOrgMedia:
        case WBUserVerifiedTypeOrgWebsite:
        {
            self.verifiedView.hidden=NO;
            self.verifiedView.image = [UIImage imageNamed:@"avatar_enterprise_vip"];
            break;
        }
        case WBUserVerifiedTypeDaren:
        {
            self.verifiedView.hidden=NO;
            self.verifiedView.image = [UIImage imageNamed:@"avatar_grassroot"];
            break;
        }
        default:
            self.verifiedView.hidden = YES;
            break;
    }
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    self.verifiedView.size = self.verifiedView.image.size;
    self.verifiedView.x = self.width-0.6*self.verifiedView.width;
    self.verifiedView.y = self.height-0.7*self.verifiedView.height;
}

@end
