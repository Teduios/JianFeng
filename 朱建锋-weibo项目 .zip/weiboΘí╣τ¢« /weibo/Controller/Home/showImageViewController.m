//
//  showImageViewController.m
//  weibo
//
//  Created by apple-jd37 on 15/11/23.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "showImageViewController.h"
#import "SDWebImageManager.h"
#import "MBProgressHUD+MJ.h"
#import "UIImageView+WebCache.h"

@interface showImageViewController () <UIScrollViewDelegate,SDWebImageManagerDelegate>
@property (nonatomic,strong) UIScrollView  *sv;
@property (nonatomic,strong) UIImageView  *iv;
@end

@implementation showImageViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    [MBProgressHUD showMessage:@"图片正在加载中"];
    [[[SDWebImageManager sharedManager] imageCache] clearMemory];
    
    self.tabBarController.tabBar.hidden = YES;
    self.view.backgroundColor = [UIColor whiteColor];
    //替换字段
    NSString *replace = @"bmiddle";
    NSRange range = NSMakeRange(22, 9);
    NSString *realImage = [self.imagePath stringByReplacingCharactersInRange:range withString:replace];
//    NSLog(@"%@",realImage);
    //新建一个scrollView
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, viewWidth, viewHeight)];
    scrollView.bounces = NO;
    self.sv = scrollView;

    
    //新建imageView
    UIImageView *imageView = [[UIImageView alloc] init];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    
    [imageView sd_setImageWithURL:[NSURL URLWithString:realImage] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        [MBProgressHUD hideHUD];
    }];
    
//    [imageView sd_setImageWithURL:[NSURL URLWithString:realImage]];
    
    imageView.backgroundColor = [UIColor redColor];
   
    self.iv = imageView;
    [scrollView addSubview:imageView];
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.left.right.equalTo(scrollView);
        make.top.mas_equalTo(scrollView);
        make.left.mas_equalTo(0);
        make.right.mas_equalTo(0);
        make.bottom.equalTo(scrollView).mas_offset(-[[UIApplication sharedApplication] statusBarFrame].size.height);
    }];
    
    
    
//    scrollView.contentSize = CGSizeMake(imageView.width, imageView.height);
    scrollView.maximumZoomScale = 5;
//    CGFloat xScale = scrollView.frame.size.width/imageView.frame.size.width;
//    CGFloat yScale = scrollView.frame.size.height/imageView.frame.size.height;
    scrollView.minimumZoomScale = 1;//MIN(xScale, yScale);
    scrollView.delegate = self;
     [self.view addSubview:scrollView];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setTitle:@"返回" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    btn.frame = CGRectMake(0, 0, 45, 45);
    [btn addTarget:self action:@selector(gotoBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithCustomView:btn];
    self.navigationItem.leftBarButtonItem = item;


}

- (void)gotoBack
{
//    self.view.backgroundColor = [UIColor whiteColor];
    self.tabBarController.tabBar.hidden = NO;
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    [[[SDWebImageManager sharedManager] imageCache] clearMemory];
    [[SDImageCache sharedImageCache] setValue:nil forKey:@"memCache"];
}

#pragma mark - 滚动视图的代理协议方法

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return self.iv;
}

@end
