//
//  dropDownView.h
//  weibo
//
//  Created by apple-jd37 on 15/11/4.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import <UIKit/UIKit.h>
@class dropDownView;
@protocol dropDownViewDelegate <NSObject>

- (void)dropdownMenuDidShow:(dropDownView *)view;
- (void)dropdownMenuDidDismiss:(dropDownView *)view;

@end

@interface dropDownView : UIView
@property (nonatomic,weak) id<dropDownViewDelegate>  delegate;
+ (instancetype)view;

//显示
- (void)showFrom:(UIView *)view;
//销毁
- (void)dismiss;
//内容
@property (nonatomic,strong) UIView  *content;

//内容控制器
@property (nonatomic,strong) UIViewController  *contentController;

@end
