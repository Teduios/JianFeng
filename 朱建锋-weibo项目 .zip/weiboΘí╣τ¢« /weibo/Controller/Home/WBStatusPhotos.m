//
//  WBStatusPhotos.m
//  weibo
//
//  Created by apple-jd37 on 15/11/13.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "WBStatusPhotos.h"
#import "WBStatuPhoto.h"

#define realStandarForCount(count) ((count==4)?2:3)
@implementation WBStatusPhotos //9

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        self.contentMode = UIViewContentModeCenter;
        self.clipsToBounds = YES;
    }
    return self;
}
//返回相册大小规格
+ (CGSize)sizeWithCount:(NSInteger)count
{
    //规格声明
    NSInteger standar = realStandarForCount(count);
    //列数
    NSInteger col = (count>=standar)?standar:count;
    //图片相册宽度
    CGFloat photoW = WBPhotoWH *col+(col-1)*spaceWH;
    //行数
    NSInteger row = (count+standar - 1)/standar;
    //图片相册高度
    CGFloat photoH = WBPhotoWH *row+(row-1)*spaceWH;
    return CGSizeMake(photoW, photoH);
}
//重写set方法,设置图片等
- (void)setPhotos:(NSArray *)photos
{
    _photos = photos;
    
    //需要显示的图片数量
    NSInteger phototCount = photos.count; //6
    
    //如果传入的照片数量超过现有的，要新创建新的,只要未满足，就一直创建
    while (self.subviews.count<phototCount) {
        WBStatuPhoto *imageView = [[WBStatuPhoto alloc] init];
        [self addSubview:imageView];
    }
    //布局所有需要显示的图片控件，设置图片
    
    
    for (int i =0; i<self.subviews.count; i++) {
        WBStatuPhoto *photoImage = self.subviews[i];
        if (i<phototCount) { //如果是符合传进来图片数量的imageView则显示，其余的则隐藏
            //显示
           photoImage.photo = photos[i];
           photoImage.imageArr = self.subviews;
            photoImage.hidden = NO;
            
            
        }else{
            photoImage.hidden = YES;
        }
    }
}
//布局控件调用，定义控件位置
- (void)layoutSubviews
{
    [super layoutSubviews];
    NSInteger photoCount =self.photos.count;
    NSInteger standar =realStandarForCount(photoCount);
    for (int i=0; i<photoCount; i++) {
        WBStatuPhoto *imageView = self.subviews[i];
        NSInteger col = i%standar;
        NSInteger row = i/standar;
        imageView.x = col*(WBPhotoWH+spaceWH);
        imageView.y = row*(WBPhotoWH+spaceWH);
        imageView.width = WBPhotoWH;
        imageView.height = WBPhotoWH;
    }
    
}

//- (void)clickImage:(UITapGestureRecognizer *)recognizer
//{
//
//     NSLog(@"点击了原创配图");
//}


@end
