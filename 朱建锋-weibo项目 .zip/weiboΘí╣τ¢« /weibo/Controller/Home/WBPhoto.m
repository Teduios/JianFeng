//
//  WBPhoto.m
//  weibo
//
//  Created by apple-jd37 on 15/11/9.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "WBPhoto.h"

@implementation WBPhoto

@end
