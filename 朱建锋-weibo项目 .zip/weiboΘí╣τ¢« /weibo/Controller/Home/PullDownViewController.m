//
//  PullDownViewController.m
//  weibo
//
//  Created by apple-jd37 on 15/11/3.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "PullDownViewController.h"

@interface PullDownViewController () 

@end

@implementation PullDownViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //设置表哥下划线取消
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"Cell"];
//    self.tableView.backgroundColor = [UIColor yellowColor];
   
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return 13;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
//    if (!cell) {
//        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Cell"];
//    }
//    cell.backgroundColor = SetColor(132, 132, 132);
//    cell.textLabel.textColor = [UIColor blackColor];
    switch (indexPath.row) {
        case 0:
            cell.textLabel.text = @"首页";
            break;
        case 1:
            cell.textLabel.text = @"互相关注";
            break;
        case 2:
            cell.textLabel.text = @"我的微博";
            break;
        case 3:
            cell.textLabel.text = @"周边微博";
            break;
        case 4:
            cell.textLabel.text = @"特别关注";
            break;
        case 5:
            cell.textLabel.text = @"同学";
            break;
        case 6:
            cell.textLabel.text = @"家人";
            break;
        case 7:
            cell.textLabel.text = @"同事";
            break;
        case 8:
            cell.textLabel.text = @"其他";
            break;
        case 9:
            cell.textLabel.text = @"明星";
            break;
        case 10:
            cell.textLabel.text = @"朋友";
            break;
        case 11:
            cell.textLabel.text = @"悄悄关注";
            break;
        case 12:{
            UIButton *button = [[UIButton alloc] init];
            button.titleLabel.text = @"编辑我的分组";
            [cell.contentView  addSubview:button];
            break;
        }
        default:
            break;
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
     NSLog(@"%ld",indexPath.row);
//    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

@end









