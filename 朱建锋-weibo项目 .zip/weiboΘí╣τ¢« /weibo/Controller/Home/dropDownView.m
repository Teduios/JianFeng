//
//  dropDownView.m
//  weibo
//
//  Created by apple-jd37 on 15/11/4.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "dropDownView.h"

@interface dropDownView ()
@property (nonatomic,weak) UIImageView  *imageView;

@end

@implementation dropDownView

- (UIImageView *)imageView
{
    if (!_imageView) {
        UIImageView *imageView = [[UIImageView alloc] init];
        imageView.image = [UIImage imageNamed:@"popover_background"];
        imageView.userInteractionEnabled = YES;
        [self addSubview:imageView];
        self.imageView = imageView;
    }
    return _imageView;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        //清除颜色
        self.backgroundColor = [UIColor clearColor];
    }
    return self;
}

+ (instancetype)view
{
    return [[self alloc] init];
}

- (void)setContent:(UIView *)content
{
    _content= content;
    // 调整内容的位置
    content.x = 10;
    content.y = 15;
    
    // 设置灰色的高度
    self.imageView.height = CGRectGetMaxY(content.frame) + 11;
    // 设置灰色的宽度
    self.imageView.width = CGRectGetMaxX(content.frame) + 10;
    
    // 添加内容到灰色图片中
    [self.imageView addSubview:content];
}
- (void)setContentController:(UIViewController *)contentController
{
    _contentController = contentController;
    self.content = contentController.view;
}

- (void)showFrom:(UIView *)view
{
    // 1.获得最上面的窗口
    UIWindow *window = [[UIApplication sharedApplication].windows lastObject];
    
    // 2.添加自己到窗口上
    [window addSubview:self];
    
    // 3.设置尺寸
    self.frame = window.bounds;
    
    // 4.调整灰色图片的位置
    // 默认情况下，frame是以父控件左上角为坐标原点
    // 转换坐标系
    CGRect newFrame = [view convertRect:view.bounds toView:window];
    //    CGRect newFrame = [from.superview convertRect:from.frame toView:window];
    self.imageView.centerX = CGRectGetMidX(newFrame);
    self.imageView.y = CGRectGetMaxY(newFrame);
    
    // 通知外界，自己显示了，防御性措施
    if ([self.delegate respondsToSelector:@selector(dropdownMenuDidShow:)]) {
        [self.delegate dropdownMenuDidShow:self];
    }

}
- (void)dismiss
{
    [self removeFromSuperview];
    // 通知外界，自己被销毁了，防御性措施
    if ([self.delegate respondsToSelector:@selector(dropdownMenuDidDismiss:)]) {
        [self.delegate dropdownMenuDidDismiss:self];
    }
    
}
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self dismiss];
  
}

@end







