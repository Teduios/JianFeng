//
//  QRcodeViewController.m
//  weibo
//
//  Created by apple-jd37 on 15/11/25.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "QRcodeViewController.h"
#import "NSString+QRCode.h"
#import <AVFoundation/AVFoundation.h>
#import "PersonMessage.h"
#import "UIImageView+WebCache.h"

@interface QRcodeViewController () <AVCaptureMetadataOutputObjectsDelegate>
@property (nonatomic,strong) UIImageView  *imageView;
@end

@implementation QRcodeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg0"]];
    self.navigationItem.title = @"二维码";
    
    //新建一个UIImageView
    UIImageView *imageView = [[UIImageView alloc] init];
    imageView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"qrcode_border"]];
    self.imageView = imageView;
    imageView.hidden = YES;
    [self.view addSubview:imageView];
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.mas_equalTo(0);
        make.width.height.mas_equalTo(180);
    }];
    
    //新建个人头像ImageView
    PersonMessage *message = [PersonMessage acounted];
    UIImageView *iconView = [[UIImageView alloc] init];
    iconView.backgroundColor = [UIColor redColor];
        [iconView sd_setImageWithURL:[NSURL URLWithString:message.profile_image_url]];
        iconView.layer.cornerRadius = 20;
        iconView.clipsToBounds = YES;
    [imageView addSubview:iconView];
    [iconView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.mas_equalTo(0);
        make.width.height.mas_equalTo(40);
    }];
    
    //新建一个button
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(50, 30, viewWidth-100, 40)];
//    btn.backgroundColor = [UIColor redColor];
    [btn setBackgroundImage:[UIImage imageNamed:@"popwindow_background"] forState:UIControlStateNormal];
    [btn setTitle:@"点击生成二维码～～" forState:UIControlStateNormal];
    btn.titleLabel.font = [UIFont systemFontOfSize:20];
    [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(clickQRCode) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:btn];
    
}

- (void)clickQRCode
{
    PersonMessage *message = [PersonMessage acounted];
    NSString *prefix = [NSString stringWithFormat:@"http://weibo.com/%@",message.domain];
    self.imageView.image = [prefix imageForQRCode:self.imageView.frame.size.width];
    self.imageView.hidden = NO;
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
