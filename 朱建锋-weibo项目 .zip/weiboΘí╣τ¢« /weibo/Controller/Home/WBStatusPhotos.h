//
//  WBStatusPhotos.h
//  weibo
//
//  Created by apple-jd37 on 15/11/13.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WBStatusPhotos : UIView

//创建相册数组
@property (nonatomic,strong) NSArray  *photos;
//计算相册尺寸
+ (CGSize)sizeWithCount:(NSInteger)count;

@property (nonatomic,strong) NSString  *image;

@end
