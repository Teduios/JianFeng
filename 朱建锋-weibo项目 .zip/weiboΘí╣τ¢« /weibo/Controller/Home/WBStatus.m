//
//  WBStatus.m
//  weibo
//
//  Created by apple-jd37 on 15/11/5.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "WBStatus.h"
#import "MJExtension.h"
#import "WBPhoto.h"
@implementation WBStatus

+ (NSDictionary *)objectClassInArray
{
    return @{@"pic_urls":[WBPhoto class]};
}

- (NSString *)created_at
{
    //Thu Nov 12 18:18:03 +0800 2015
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    //如果是真机调试，转换这种欧美时间，需要设置lacale
    formatter.locale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    //设置格式
    formatter.dateFormat = @"EEE MMM dd HH:mm:ss Z yyyy";
    //微博的创建日期
    NSDate *createDate = [formatter dateFromString:_created_at];
    //获取当前时间
    NSDate *now = [NSDate date];
    //时间日历
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSCalendarUnit unit = NSCalendarUnitYear | NSCalendarUnitMonth |NSCalendarUnitDay |
    NSCalendarUnitHour |
    NSCalendarUnitMinute |
    NSCalendarUnitSecond;
    NSDateComponents *cmp = [calendar components:unit fromDate:createDate toDate:now options:0];
    
    if ([createDate isThisYear]) { //今年
        if ([createDate isYesterday]) {  //昨天
            formatter.dateFormat = @"昨天 HH:mm";
            return [formatter stringFromDate:createDate];
        }else if([createDate isToday]){ //今天
            if (cmp.hour>=1) {
                return [NSString stringWithFormat:@"%ld小时之前",cmp.hour];
            }else if(cmp.minute>=1){
                return [NSString stringWithFormat:@"%ld分钟之前",cmp.minute];
            }else{
                return @"刚刚"; 
            }
        }else{
            formatter.dateFormat = @"MM-dd HH:mm";
            return [formatter stringFromDate:createDate];
        }
    }else{ //不是今年
        formatter.dateFormat = @"yyyy-MM-dd HH:mm";
        return [formatter stringFromDate:createDate];
    }
}

- (void)setSource:(NSString *)source
{
    _source = source;
    if (source.length!=0) {
        NSRange range;
        //获取想获取字符串的原点和长度
        range.location = [source rangeOfString:@">"].location+1;
        range.length = [source rangeOfString:@"</"].location - range.location;
        _source = [NSString stringWithFormat:@"来自：%@",[source substringWithRange:range]];

    }
}


@end





