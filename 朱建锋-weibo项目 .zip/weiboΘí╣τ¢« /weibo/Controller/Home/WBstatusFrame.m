//
//  WBstatusFrame.m
//  weibo
//
//  Created by apple-jd37 on 15/11/8.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "WBstatusFrame.h"
#import "WBStatus.h"
#import "WBUserInfo.h"
#import "WBStatusPhotos.h"

@implementation WBstatusFrame


- (void)setStatues:(WBStatus *)statues
{
    _statues = statues;
    WBUserInfo *user = statues.user;
    //cell的宽度
    CGFloat cellWidth = [UIScreen mainScreen].bounds.size.width;
    /** 原创微博cell的frame布局*/
    //头像
    CGFloat iconWH = 35;
    CGFloat iconX = spaceWH;
    CGFloat iconY = spaceWH;
    self.iconImageViewFrame = CGRectMake(iconX, iconY, iconWH, iconWH);
    
    //昵称
    CGFloat nameX = CGRectGetMaxX(self.iconImageViewFrame)+spaceWH;
    CGFloat nameY = iconY;
    CGSize nameSize = [user.name sizeWithFont:WBUserNameFontSize];
    self.userNameFrame = (CGRect){{nameX,nameY},nameSize};
    //会员图标
    if (user.isVip) {
        CGFloat vipX = CGRectGetMaxX(self.userNameFrame)+spaceWH;
        CGFloat vipY = nameY;
        CGFloat vipW = 14;
        CGFloat vipH = nameSize.height;
        self.VipViewFrame = CGRectMake(vipX, vipY, vipW, vipH);
    }
  
    //时间
    CGFloat timeX = nameX;
    CGFloat timeY = CGRectGetMaxY(self.userNameFrame)+spaceWH;
    CGSize timeSize = [statues.created_at sizeWithFont:WBTimeFontSize];
    self.publishTimeFrame = (CGRect){{timeX,timeY},timeSize};
    //来源
    CGFloat sourceX = CGRectGetMaxX(self.publishTimeFrame)+spaceWH;
    CGFloat sourceY = timeY;
    CGSize sourceSize = [statues.source sizeWithFont:WBTimeFontSize];
    self.publishPathFrame = (CGRect){{sourceX,sourceY},sourceSize};
   
    //正文
    CGFloat contentX = iconX;
    CGFloat contentY = MAX(CGRectGetMaxY(self.iconImageViewFrame), CGRectGetMaxY(self.publishTimeFrame))+spaceWH;
    CGFloat maxW = cellWidth - 2*spaceWH;
    CGSize contentSize = [statues.text sizeWithFont:WBTextFontSize maxW:maxW];
    self.publishTextFrame = (CGRect){{contentX,contentY},contentSize};
    //配图
    CGFloat originalH=0;
    if (statues.pic_urls.count) {
        //如果有配图
        CGSize photoSize = [WBStatusPhotos sizeWithCount:statues.pic_urls.count];
        CGFloat photoX = contentX;
        CGFloat photoY = CGRectGetMaxY(self.publishTextFrame)+spaceWH;
        self.photoViewFrame = (CGRect){{photoX,photoY}, photoSize};
        originalH = CGRectGetMaxY(self.photoViewFrame)+spaceWH;
    }else{
        //如果没有配图
        originalH = CGRectGetMaxY(self.publishTextFrame)+spaceWH;
    }
    CGFloat toolbarY =0;
    //原创微博整体
    CGFloat mainViewX = 0;
    CGFloat mainViewY = WBCellSpace;
    CGFloat mainViewW = cellWidth;
    self.contentMViewFrame = CGRectMake(mainViewX, mainViewY,mainViewW, originalH);
    
    if (statues.retweeted_status) {  //如果转发微博存在
        //方便拿到模型
        WBStatus *replyStatus = statues.retweeted_status;
        WBUserInfo *replayUser = replyStatus.user;
        //转发微博内容
        CGFloat replayContentX = spaceWH;
        CGFloat replayContentY = spaceWH;
        NSString *content = [NSString stringWithFormat:@"%@ :%@",replayUser.name,replyStatus.text];
        CGSize contentSize = [content sizeWithFont:WBTextFontSize maxW:maxW];
        self.replayContentFrame = (CGRect){{replayContentX,replayContentY},contentSize};
        //转发微博配图
        //转发微博整体
        CGFloat replayH =0;
        
        if (replyStatus.pic_urls.count) {
            //如果转发微博配图存在
            CGFloat replayImageX = replayContentX;
            CGFloat replayImageY = CGRectGetMaxY(self.replayContentFrame)+spaceWH;
            CGSize replayImageSize = [WBStatusPhotos sizeWithCount:replyStatus.pic_urls.count];
            self.replayImageViewFrame = (CGRect){{replayImageX, replayImageY}, replayImageSize};
            replayH = CGRectGetMaxY(self.replayImageViewFrame)+spaceWH;
            
        }else{
            replayH = CGRectGetMaxY(self.replayContentFrame)+spaceWH;
        }
        //被转发微博整体
        CGFloat replayX = 0;
        CGFloat replayY = CGRectGetMaxY(self.contentMViewFrame);
        CGFloat replayW =cellWidth;
        self.replayViewFrame = CGRectMake(replayX, replayY, replayW, replayH);
        toolbarY = CGRectGetMaxY(self.replayViewFrame);

    }else{
        toolbarY = CGRectGetMaxY(self.contentMViewFrame)+1;
    }
        //工具条
    CGFloat toolbarX = 0;
    CGFloat toolbarW = cellWidth;
    CGFloat toolbarH = 35;
    self.WBToolBarFrame = CGRectMake(toolbarX, toolbarY, toolbarW, toolbarH);
    self.cellHeight = CGRectGetMaxY(self.WBToolBarFrame);
}


@end




