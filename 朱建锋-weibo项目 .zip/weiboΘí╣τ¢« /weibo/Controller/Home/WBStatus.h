//
//  WBStatus.h
//  weibo
//
//  Created by apple-jd37 on 15/11/5.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import <Foundation/Foundation.h>
@class WBUserInfo;
 
@interface WBStatus : NSObject


//微博信息内容
@property (nonatomic,copy) NSString  *text;
//字符串型的微博ID
@property (nonatomic,copy) NSString  *idstr;
//微博作者的用户信息字段
@property (nonatomic,strong) WBUserInfo  *user;
//微博创建时间
@property (nonatomic,copy) NSString  *created_at;
//微博来源
@property (nonatomic,copy) NSString  *source;
//微博配图地址，多图时返回多图链接，无配图返回[]
@property (nonatomic,strong) NSArray  *pic_urls;

//被转发的原微博信息字段，当该微博为转发微博时返回
@property (nonatomic,strong) WBStatus  *retweeted_status;
//转发数
@property (nonatomic,assign) int  reposts_count;
//评论数
@property (nonatomic,assign) int  comments_count;
//表态数
@property (nonatomic,assign) int  attitudes_count;

//中等配图
@property (nonatomic,assign) NSString  *bmiddle_pic;
//大配图
@property (nonatomic,assign) NSString  *original_pic;

@end
