//
//  WBStatusCell.m
//  weibo
//
//  Created by apple-jd37 on 15/11/7.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

//
#import "WBStatusCell.h"
#import "WBIconPhoto.h"
#import "WBStatusPhotos.h"
#import "WBtoolBar.h"
#import "WBStatus.h"
#import "WBstatusFrame.h"
#import "WBUserInfo.h"

@interface WBStatusCell ()
//微博主view
@property (nonatomic,weak) UIView  *contentMView;
//用户头像
@property (nonatomic,weak) WBIconPhoto  *iconImageView;
//用户等级
@property (nonatomic,weak) UIImageView  *VipView;
//配图
@property (nonatomic,weak) WBStatusPhotos  *photoView;
//用户昵称
@property (nonatomic,weak) UILabel  *userName;
//发表时间
@property (nonatomic,weak) UILabel  *publishTime;
//发表途径
@property (nonatomic,weak) UILabel  *publishPath;
//发表内容正文
@property (nonatomic,weak) UILabel  *publishText;

//转发微博主体View
@property (nonatomic,weak) UIView  *replayView;
//转发微博人 昵称 + 内容
@property (nonatomic,weak) UILabel  *replayContent;
//转发微博配图
@property (nonatomic,weak) WBStatusPhotos  *replayImageView;

//转发评论赞的工具条
@property (nonatomic,weak) WBtoolBar  *WBtoolBar;


@end

@implementation WBStatusCell

+ (instancetype)cellWithTableView:(UITableView *)tableView
{
    NSString *ID = @"Cell";
    WBStatusCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell = [[WBStatusCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:ID];
     }
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        //原创微博
        [self showOriginView];
        //转发微博
        [self showreplayView];
        //工具条
        [self showWBToolBar];
        self.contentView.backgroundColor = SetColor(211, 211, 211);
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return self;
}
/**
 *  原创微博部分
 */
- (void)showOriginView
{
    //微博主view
    UIView *contentMView = [[UIView alloc] init];
            contentMView.backgroundColor = [UIColor whiteColor];
    [self.contentView addSubview:contentMView];
    self.contentMView = contentMView;
    //用户头像
    WBIconPhoto  *iconImageView = [[WBIconPhoto alloc] init];
    [contentMView addSubview:iconImageView];
    self.iconImageView = iconImageView;
    //用户等级
    UIImageView  *VipView = [[UIImageView alloc] init];
    VipView.contentMode = UIViewContentModeCenter;
    [contentMView addSubview:VipView];
    self.VipView = VipView;
    //配图
    WBStatusPhotos  *photoView = [[WBStatusPhotos alloc] init];
    [contentMView addSubview:photoView];
    self.photoView = photoView;
    //用户昵称
    UILabel  *userName = [[UILabel alloc] init];
    userName.font = WBUserNameFontSize;
    [contentMView addSubview:userName];
    self.userName = userName;
    //发表时间
    UILabel  *publishTime = [[UILabel alloc] init];
    publishTime.textColor = [UIColor orangeColor];
    publishTime.font = WBTimeFontSize;
    [contentMView addSubview:publishTime];
    self.publishTime = publishTime;
    //发表途径
    UILabel  *publishPath  = [[UILabel alloc] init];
    publishPath.textColor = SetColor(132, 132, 132);
    publishPath.font = WBTimeFontSize;
    [contentMView addSubview:publishPath];
    self.publishPath = publishPath;
    //发表内容正文
    UILabel  *publishText = [[UILabel alloc] init];
    publishText.font = WBTextFontSize;
    publishText.numberOfLines = 0;
    [contentMView addSubview:publishText];
    self.publishText = publishText;
}
/**
 *  转发微博部分
 */
- (void)showreplayView
{
    //转发微博主view
    UIView *replayView = [[UIView alloc] init];
    replayView.backgroundColor = SetColor(247, 247, 247);
    [self.contentView addSubview:replayView];
    self.replayView = replayView;
    //转发微博内容
    UILabel *relayContent = [[UILabel alloc] init];
    relayContent.font = WBTextFontSize;
    relayContent.numberOfLines = 0;
    [replayView addSubview:relayContent];
    self.replayContent = relayContent;
    //转发微博配图
    WBStatusPhotos  *replayImageView = [[WBStatusPhotos alloc] init];
    [replayView addSubview:replayImageView];
    self.replayImageView = replayImageView;
}
/**
 *  工具条
 */
- (void)showWBToolBar
{
    WBtoolBar *toolBarView = [WBtoolBar toolBar];
    [self.contentView addSubview:toolBarView];
    self.WBtoolBar = toolBarView;
}

- (void)setStatusFrame:(WBstatusFrame *)statusFrame
{
    _statusFrame =statusFrame;
    
    WBStatus *statuses = statusFrame.statues;
    WBUserInfo *user = statuses.user;
    
    //原创微博整体
    self.contentMView.frame = statusFrame.contentMViewFrame;
    //头像
    self.iconImageView.frame = statusFrame.iconImageViewFrame;
    self.iconImageView.user = user;
    //用户等级
    if (user.isVip) {
        //如果存在会员，则显示
        self.VipView.hidden = NO;
        self.VipView.frame = statusFrame.VipViewFrame;
        NSString *vipName = [NSString stringWithFormat:@"common_icon_membership_level%d",user.mbrank];
        self.VipView.image = [UIImage imageNamed:vipName];
        self.userName.textColor = [UIColor orangeColor];
    }else{
        self.VipView.hidden = YES;
        self.userName.textColor = [UIColor blackColor];
    }
    //配图
    if (statuses.pic_urls.count) {
        //如果配图存在
//         NSLog(@"%@,%@",statuses.bmiddle_pic,statuses.original_pic);
//        if ((statuses.bmiddle_pic && statuses.original_pic) || statuses.bmiddle_pic)
//        {
//            self.photoView.image = @"bmiddle";
//        }else if(statuses.original_pic){
//            self.photoView.image = @"original";
//        }
        self.photoView.frame = statusFrame.photoViewFrame;
//        WBPhoto *photo = [statuses.pic_urls firstObject];
        self.photoView.photos = statuses.pic_urls;
        self.photoView.hidden = NO;
    }else{
        self.photoView.hidden = YES;
    }
    self.photoView.frame = statusFrame.photoViewFrame;
    //用户昵称
    self.userName.text = user.name;
    self.userName.frame = statusFrame.userNameFrame;
    
   //发表时间
    NSString *time = statuses.created_at;
    CGFloat timeX = statusFrame.userNameFrame.origin.x;
    CGFloat timeY = CGRectGetMaxY(statusFrame.userNameFrame)+spaceWH;
    CGSize timeSize = [time sizeWithFont:WBTimeFontSize];
    self.publishTime.frame = (CGRect){{timeX,timeY},timeSize};
    self.publishTime.text = statuses.created_at;
    
    //发表途径
    CGFloat sourceX = CGRectGetMaxX(self.publishTime.frame)+spaceWH;
    CGFloat sourceY = timeY;
    CGSize sourceSize = [statuses.source sizeWithFont:WBTimeFontSize];
    self.publishPath.frame = (CGRect){{sourceX,sourceY},sourceSize};
    self.publishPath.text = statuses.source;
    
    //发表内容正文
    self.publishText.frame = statusFrame.publishTextFrame;
    self.publishText.text = statuses.text;
    //转发微博
    if (statuses.retweeted_status) {
        //如果转发微博存在
        WBStatus *replayStatus = statuses.retweeted_status;
        WBUserInfo *replayUser = replayStatus.user;
        
        self.replayView.frame = statusFrame.replayViewFrame;
        self.replayView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"timeline_image_placeholder"]];
        self.replayView.hidden = NO;
        //被转发微博内容
        self.replayContent.frame = statusFrame.replayContentFrame;
        self.replayContent.text = [NSString stringWithFormat:@"%@ :%@",replayUser.name,replayStatus.text];
        //被转发微博配图
        if (replayStatus.pic_urls.count) {
            //如果配图存在
            
//            NSLog(@"%@,%@",replayStatus.bmiddle_pic,replayStatus.original_pic);
//            if ((replayStatus.bmiddle_pic && replayStatus.original_pic) || replayStatus.bmiddle_pic)
//            {
//                self.replayImageView.image = @"bmiddle";
//            }else if(replayStatus.original_pic){
//                self.replayImageView.image = @"original";
//            }
//
            
            self.replayImageView.frame = statusFrame.replayImageViewFrame;
//            WBPhoto *photo = [replayStatus.pic_urls firstObject];
            self.replayImageView.photos = replayStatus.pic_urls;
            self.replayImageView.hidden = NO;
        }else{
            self.replayImageView.hidden = YES;
        }
    }else{
        self.replayView.hidden = YES;
    }
    //工具条
    self.WBtoolBar.frame = statusFrame.WBToolBarFrame;
    self.WBtoolBar.status = statuses;
//    self.WBtoolBar.backgroundColor = [UIColor redColor];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}




@end




