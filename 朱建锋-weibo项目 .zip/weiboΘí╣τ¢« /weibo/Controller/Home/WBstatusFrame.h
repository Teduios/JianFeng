//
//  WBstatusFrame.h
//  weibo
//
//  Created by apple-jd37 on 15/11/8.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import <Foundation/Foundation.h>

@class WBStatus;
@interface WBstatusFrame : NSObject
@property (nonatomic,strong) WBStatus   *statues;
//微博主view
@property (nonatomic,assign) CGRect   contentMViewFrame;
//用户头像
@property (nonatomic,assign) CGRect   iconImageViewFrame;
//用户等级
@property (nonatomic,assign) CGRect   VipViewFrame;
//配图
@property (nonatomic,assign) CGRect   photoViewFrame;
//用户昵称
@property (nonatomic,assign) CGRect   userNameFrame;
//发表时间
@property (nonatomic,assign) CGRect   publishTimeFrame;
//发表途径
@property (nonatomic,assign) CGRect   publishPathFrame;
//发表内容正文
@property (nonatomic,assign) CGRect   publishTextFrame;

//转发微博主view
@property (nonatomic,assign) CGRect  replayViewFrame;
//转发微博内容
@property (nonatomic,assign) CGRect  replayContentFrame;
//转发微博配图
@property (nonatomic,assign) CGRect  replayImageViewFrame;

//工具条
@property (nonatomic,assign) CGRect  WBToolBarFrame;

//cell高度
@property (nonatomic,assign) CGFloat  cellHeight;


@end
