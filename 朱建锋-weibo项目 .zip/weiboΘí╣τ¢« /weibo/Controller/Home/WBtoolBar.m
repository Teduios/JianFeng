//
//  WBtoolBar.m
//  weibo
//
//  Created by apple-jd37 on 15/11/11.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "WBtoolBar.h"
#import "WBStatus.h"

@interface WBtoolBar ()

@property (nonatomic,strong) NSMutableArray  *btns;
@property (nonatomic,strong) NSMutableArray  *dividers;

@property (nonatomic,strong) UIButton  *repostsBtn;
@property (nonatomic,strong) UIButton  *commentsBtn;
@property (nonatomic,strong) UIButton  *attitudesBtn;
@end


@implementation WBtoolBar
- (NSMutableArray *)btns
{
    if (!_btns) {
        _btns  = [NSMutableArray array];
    }
    return _btns;
}
- (NSMutableArray *)dividers
{
    if (!_dividers) {
        _dividers = [NSMutableArray array];
    }
    return _dividers;
}

+ (instancetype)toolBar
{
    return [[self alloc] init];
}


- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"timeline_card_middle_background"]];
        //添加按钮
      self.repostsBtn =  [self setUpButtonWithTitle:@"转发" andImage:@"timeline_icon_retweet"];
       self.commentsBtn = [self setUpButtonWithTitle:@"评论" andImage:@"timeline_icon_comment"];
      self.attitudesBtn =  [self setUpButtonWithTitle:@"赞" andImage:@"timeline_icon_unlike"];
        //添加分割线
        [self setupDevider];
        [self setupDevider];
    }
    return self;
}
- (void)setupDevider
{
    UIImageView *divider = [[UIImageView alloc] init];
    divider.image = [UIImage imageNamed:@"timeline_card_bottom_line"];
    [self addSubview:divider];
    [self.dividers addObject:divider];
}
//自定义的类布局要在这个方法中
- (void)layoutSubviews
{
    [super layoutSubviews];
    //布局按钮
    NSInteger btnCount = self.btns.count;
    CGFloat btnW = self.width/3;
    CGFloat btnH = self.height;
    for (int i=0; i<btnCount; i++) {
        UIButton *btn = self.subviews[i];
        CGFloat btnX = i*btnW;
        CGFloat btnY = 0;
        btn.frame = CGRectMake(btnX, btnY, btnW, btnH);
    }
    //布局间隔
    NSInteger divideCount = self.dividers.count;
    for (int i=0; i<divideCount; i++) {
        UIImageView *divideImage =self.dividers[i];
        divideImage.width =1;
        divideImage.height = btnH;
        divideImage.x = (i+1)*btnW;
        divideImage.y = 0;
    }
   
}

- (void)setStatus:(WBStatus *)status
{
    _status = status;
    [self setUpBtnCount:status.reposts_count btn:self.repostsBtn title:@"转发"];
    [self setUpBtnCount:status.comments_count btn:self.commentsBtn title:@"评论"];
    [self setUpBtnCount:status.attitudes_count btn:self.attitudesBtn title:@"赞"];

}
/**
 *  按钮的方法
 */
- (UIButton *)setUpButtonWithTitle:(NSString *)title andImage:(NSString *)image
{
    UIButton *btn = [[UIButton alloc] init];
    btn.titleEdgeInsets = UIEdgeInsetsMake(0, 5, 0, 0);
    btn.titleLabel.font = [UIFont systemFontOfSize:12];
    [btn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    [btn setImage:[UIImage imageNamed:image] forState:UIControlStateNormal];
    [btn setTitle:title forState:UIControlStateNormal];
    [btn setBackgroundImage:[UIImage imageNamed:@"timeline_card_bottom_background_highlighted"] forState:UIControlStateHighlighted];
    [self addSubview:btn];
    [self.btns addObject:btn];
    return btn;
}

-(void)setUpBtnCount:(int)count btn:(UIButton *)btn title:(NSString *)title
{
    if (count) {
        if (count<10000) { //小于10000则显示全部数字
             title = [NSString stringWithFormat:@"%d",count];
             [btn setTitle:title forState:UIControlStateNormal];
        }else { //大于10000
            double number = count/10000.0;
            title = [NSString stringWithFormat:@"%.1f万",number];
            title = [title stringByReplacingOccurrencesOfString:@".0" withString:@""];
             [btn setTitle:title forState:UIControlStateNormal];
        }
       
    }else{
        [btn setTitle:title forState:UIControlStateNormal];
    }
}


@end
