//
//  WBUserInfo.m
//  weibo
//
//  Created by apple-jd37 on 15/11/5.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "WBUserInfo.h"

@implementation WBUserInfo

- (void)setMbtype:(int)mbtype
{
    _mbtype = mbtype;
    
    self.vip = mbtype > 2;
}

@end
