//
//  WBEmotionButton.m
//  weibo
//
//  Created by apple-jd37 on 15/11/18.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "WBEmotionButton.h"

@implementation WBEmotionButton

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        // 设置文字颜色
        [self setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self setTitleColor:[UIColor darkGrayColor] forState:UIControlStateDisabled];
        // 设置字体
        self.titleLabel.font = [UIFont systemFontOfSize:13];
    }
    return self;
}

- (void)setHighlighted:(BOOL)highlighted
{
    
}

@end
