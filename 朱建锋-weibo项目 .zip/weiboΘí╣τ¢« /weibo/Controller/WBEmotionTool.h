//
//  WBEmotionTool.h
//  weibo
//
//  Created by apple-jd37 on 15/11/21.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import <Foundation/Foundation.h>
@class WBEmotion;
@interface WBEmotionTool : NSObject

/** 将点击后的表情存入沙盒中*/
+ (void)addRecentEmotion:(WBEmotion *)emotion;

/** 从沙盒中取出最近点击过的表情*/
+ (NSArray *)recentEmotions;

@end
