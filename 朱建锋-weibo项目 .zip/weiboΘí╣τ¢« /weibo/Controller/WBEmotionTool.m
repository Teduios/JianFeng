//
//  WBEmotionTool.m
//  weibo
//
//  Created by apple-jd37 on 15/11/21.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "WBEmotionTool.h"
#import "WBEmotion.h"

//新建一个全局数组，这样不会增加io操作
static NSMutableArray *_recentEmotions;

@implementation WBEmotionTool

+ (void)initialize
{
    //加载沙盒中的表情数据
    _recentEmotions =[NSKeyedUnarchiver unarchiveObjectWithFile:WBRecentEmotionsPath];
    if (_recentEmotions == nil) {
        _recentEmotions = [NSMutableArray array];
    }
}

+ (void)addRecentEmotion:(WBEmotion *)emotion
{
    
    //删除重复的表情
    for (int i=0; i<_recentEmotions.count; i++) {
        WBEmotion *e = _recentEmotions[i];
        if ([e.chs isEqualToString:emotion.chs] || [e.code isEqualToString:emotion.code]) {
            [_recentEmotions removeObject:e];
            break;
        }
    }
    
    //将表情放到数组的最前面
    [_recentEmotions insertObject:emotion atIndex:0];
    //将所有的表情数据写入沙盒
    [NSKeyedArchiver archiveRootObject:_recentEmotions toFile:WBRecentEmotionsPath];
}

+ (NSArray *)recentEmotions
{
    return _recentEmotions;
}

@end
