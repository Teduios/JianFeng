//
//  SendWBViewController.m
//  weibo
//
//  Created by apple-jd37 on 15/11/14.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "SendWBViewController.h"
#import "WBEmotionTextView.h"
#import "SendWBStatusTool.h"
#import "SendWBphotoView.h"
#import "WBEmotionKeyBoard.h"
#import "Oauth_Account.h"


@interface SendWBViewController () <UITextViewDelegate,SendWBStatusToolDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
/** 自定义文本框*/
@property (nonatomic,weak) WBEmotionTextView  *textView;
/** 自定义下方工具条*/
@property (nonatomic,strong) SendWBStatusTool  *tool;
/** 自定义发微博带有图片的相册*/
@property (nonatomic,strong) SendWBphotoView  *photoView;
/** 自定义键盘表情*/
@property (nonatomic,strong) WBEmotionKeyBoard  *emotionKeyBoard;
/** 判断根据条件是否相应改变键盘的frame事件*/
@property (nonatomic,assign) BOOL  remarkEmotion;

@end

@implementation SendWBViewController

- (WBEmotionKeyBoard *)emotionKeyBoard
{
    if (!_emotionKeyBoard) {
        WBEmotionKeyBoard * emotionKeyBoard = [[WBEmotionKeyBoard alloc] init];
        emotionKeyBoard.width = viewWidth;
        emotionKeyBoard.height = 253;
        self.emotionKeyBoard = emotionKeyBoard;
    }
    return _emotionKeyBoard;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationController.navigationBar.hidden = NO;
    self.navigationController.navigationBar.translucent = NO;
//    self.view.backgroundColor = [UIColor yellowColor];
    //创建左上角按钮
    [self setUpLeftTopItem];
    //创建右上角按钮
    [self setUpRightTopItem];
    //创建标题
    [self setUpTitleView];
    //创建输入的文本框
    [self setUpTextView];
    //创建底部工具栏
    [self setUpBottomView];
    //添加相册
    [self setUpPhotoView];
   

}

#pragma mark -设置

/**
 *  创建一个左上角返回按钮
 */
- (void)setUpLeftTopItem
{
    //创建一个左上角返回按钮
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setTitle:@"取消" forState:UIControlStateNormal];
     btn.titleLabel.font = [UIFont systemFontOfSize:17];
    [btn setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal];
    [btn setTitleColor:SetColor(255, 248, 147) forState:UIControlStateSelected];
    btn.frame = CGRectMake(0, 0, 45, 45);
    [btn addTarget:self action:@selector(clickBackBtn) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *btnItem = [[UIBarButtonItem alloc] initWithCustomView:btn];
    self.navigationItem.leftBarButtonItem = btnItem;
    
}

/**
 *  创建一个右上角发送按钮
 */
- (void)setUpRightTopItem
{
    //创建一个右上角发送按钮
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setTitle:@"发送" forState:UIControlStateNormal];
    btn.titleLabel.font = [UIFont systemFontOfSize:17];
    [btn setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateDisabled];
    [btn setTitleColor:SetColor(255, 248, 147) forState:UIControlStateSelected];
    btn.frame = CGRectMake(0, 0, 45, 45);
    [btn addTarget:self action:@selector(sendWB) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *btnItem = [[UIBarButtonItem alloc] initWithCustomView:btn];
    self.navigationItem.rightBarButtonItem = btnItem;
    self.navigationItem.rightBarButtonItem.enabled = NO;
}
/**
 *  创建一个中间标题按钮
 */

- (void)setUpTitleView
{
    UIView *headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 120, 44)];
    UILabel *label1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0,120, 25)];
    label1.text = @"发微博";
    label1.textColor = SetColor(55, 55, 55);
    label1.font = [UIFont fontWithName:@"Baskerville" size:15];
    label1.textAlignment = NSTextAlignmentCenter;
    [headView addSubview:label1];
    Oauth_Account *acount = [Oauth_Account acounted];
    UILabel *label2 = [[UILabel alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(label1.frame), 120, 19)];
    label2.text = acount.userName;
     label2.textColor = SetColor(55, 55, 55);
    label2.font = [UIFont fontWithName:@"Baskerville" size:12];
    label2.textAlignment = NSTextAlignmentCenter;
    [headView addSubview:label2];
    self.navigationItem.titleView  =headView;
    
}
/**
 *  创建一个文本输入View
 */
- (void)setUpTextView
{
    WBEmotionTextView *textView = [[WBEmotionTextView alloc] init];
    textView.alwaysBounceVertical = YES;
    textView.delegate = self;
//    textView.backgroundColor = [UIColor yellowColor];
    textView.frame = CGRectMake(0, 0, viewWidth, 200);
    textView.placeHolder = @"分享新鲜事...";
    [self.view addSubview:textView];
    self.textView = textView;
    //文字改变的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textDidChange) name:UITextViewTextDidChangeNotification object:textView];
    //键盘改变的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillChangeFrame:) name:UIKeyboardWillChangeFrameNotification object:nil];
    //表情选中的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(emtionDidSelect:) name:@"EmotionDidNotification" object:nil];
    //删除文字的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(emotionDidDelete) name:@"EmotionDelete" object:nil];
    
}

/**
 *  创建底部工具栏
 */
- (void)setUpBottomView
{
    SendWBStatusTool *tool = [[SendWBStatusTool alloc] init];
    tool.delegate = self;
    tool.x = 0;
    tool.height = 44;
    tool.y = viewHeight-64-tool.height;
    tool.width = viewWidth;
    [self.view addSubview:tool];
    self.tool  = tool;
}

/**
 *  创建一个相册
 */
- (void)setUpPhotoView
{
    SendWBphotoView *photoView = [[SendWBphotoView alloc] init];
    photoView.y = 50;
    photoView.width  = viewWidth;
    photoView.height = 300;
    [self.textView addSubview:photoView];
    self.photoView = photoView;
}


#pragma mark - SendWBViewControllerDelegate

- (void)setUpTool:(SendWBStatusTool *)tool forType:(SendBtnType)type
{
    switch (type) {
        case SendBtnTypePhtot:
            [self takePicture];
            break;
        case SendBtnTypeLock:
             NSLog(@"圈人");
            break;
        case SendBtnTypeTopic:
             NSLog(@"话题");
            break;
        case SendBtnTypeFace:
            [self clickKeyboardEmotion];
            break;
        case SendBtnTypeLongWb:
             NSLog(@"长微博");
            break;
    }
}



#pragma mark - UIImagePickerControllerDelegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
{
    [picker dismissViewControllerAnimated:YES completion:nil];
    UIImage *image = info[UIImagePickerControllerOriginalImage];
    [self.photoView addPhoto:image];
}

#pragma mark - 监听方法

/**
 *  删除表情
 */
- (void)emotionDidDelete
{
    [self.textView deleteBackward];
}

/**
 *  点击了表情
 */
- (void)emtionDidSelect:(NSNotification *)notification
{
    WBEmotion *emotion = notification.userInfo[@"selectedEmotion"];
    [self.textView insertEmotion:emotion];
}

/**
 *  发微博
 */
- (void)sendWB
{
    if (self.photoView.photos.count) {
        [self sendWBWithTextAndImage];
    }else{
        [self sendWBOnlyText];
    }
    [self clickBackBtn];
}

/**
 *  点击键盘表情
 */
- (void)clickKeyboardEmotion
{
    if (self.textView.inputView == nil) {
        //如果当前键盘是系统自带则切换成表情键盘
        self.textView.inputView = self.emotionKeyBoard;
        //显示键盘按钮
        self.tool.showKeyboardButton = YES;
    }else{
        //切换成系统自带键盘
        self.textView.inputView = nil;
        //显示表情按钮
         self.tool.showKeyboardButton = NO;
    }
    //开始切换键盘
    self.remarkEmotion = YES;
   
    //退出键盘
    [self.textView endEditing:YES];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        [self.textView becomeFirstResponder];
        //结束切换键盘
        self.remarkEmotion=NO;
    });
    
    
}

/**
 *  拍照
 */
- (void)takePicture
{
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
        return;
    }
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.sourceType =UIImagePickerControllerSourceTypePhotoLibrary;
    picker.delegate = self;
    [self presentViewController:picker animated:YES completion:nil];
    [self.textView resignFirstResponder];
}

/**
 *  监听文字改变
 */
- (void)textDidChange
{
    self.navigationItem.rightBarButtonItem.enabled = self.textView.hasText ;
}

/**
 *  监听键盘frame改变
 */
- (void)keyboardWillChangeFrame:(NSNotification *)notification
{
    /**
     键盘动画
     UIKeyboardAnimationCurveUserInfoKey = 7;
     键盘弹起落下的时间
     UIKeyboardAnimationDurationUserInfoKey = "0.35";
     键盘升起位置
     UIKeyboardFrameEndUserInfoKey = "NSRect: {{0, 227}, {320, 253}}";
     */
    
    if (self.remarkEmotion && self.tool.showKeyboardButton ) {
        return;
    }
    NSDictionary *userInfo = notification.userInfo;
    CGFloat duration = [userInfo[UIKeyboardAnimationDurationUserInfoKey]doubleValue];
    CGRect keyboardF = [userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    [UIView animateWithDuration:duration animations:^{
        if (keyboardF.origin.y>self.view.height) {
            self.tool.y =self.view.height-self.tool.height;
        }else{
            self.tool.y = keyboardF.origin.y-self.tool.height-64;
        }
    }];
}

/**
 *  发出一个通知
 */
- (void)clickBackBtn
{
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    NSDictionary *dict = @{@"":@""};
    [center postNotificationName:@"goto" object:self userInfo:dict];
    [self.view endEditing:YES];
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - 发送微博

/**
 *  发送只有文字的微博
 */
- (void)sendWBOnlyText
{
    NSString *url = @"https://api.weibo.com/2/statuses/update.json";
    Oauth_Account *acount= [Oauth_Account acounted];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
    parameters[@"access_token"] = acount.access_token;
    parameters[@"status"] = self.textView.fullText;
    [manager POST:url parameters:parameters success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        [MBProgressHUD showSuccess:@"发送成功!"];
    } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        [MBProgressHUD showError:@"发送失败"];
    }];
    [self clickBackBtn];
    
}

/**
 *  发送带有图片的微博
 */
- (void)sendWBWithTextAndImage
{
    NSString *url = @"https://upload.api.weibo.com/2/statuses/upload.json";
    Oauth_Account *acount= [Oauth_Account acounted];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
    parameters[@"access_token"] = acount.access_token;
    parameters[@"status"] = self.textView.text;
    [manager POST:url parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        //拼接文件数据
        NSInteger count = self.photoView.photos.count;
        NSMutableData *photoData = [NSMutableData data];
        NSData *data = [NSData data];
        for (int i=0; i<count; i++) {
            UIImage *image = self.photoView.photos[i];
            data = UIImageJPEGRepresentation(image, 1.0);
             [photoData appendData:data];
        }
       
        [formData appendPartWithFileData:photoData name:@"pic" fileName:[NSString stringWithFormat:@"test.jpg"]mimeType:@"image/jpeg"];

    } success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        [MBProgressHUD showSuccess:@"发送成功"];
    } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        [MBProgressHUD showError:@"发送失败"];
         NSLog(@"%@",error.description);
    }];
}

#pragma mark - 系统方法

/**
 *  当拖拽textView时，放弃第一响应者身份
 */
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [self.view endEditing:YES];
}

/**
 *  销毁通知
 */
- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self.textView becomeFirstResponder];
}



@end
