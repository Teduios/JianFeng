//
//  WBEmotionNoHL.m
//  weibo
//
//  Created by apple-jd37 on 15/11/20.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "WBEmotionNoHL.h"
#import "WBEmotion.h"

@implementation WBEmotionNoHL

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        
    }
    return self;
}

- (void)setHighlighted:(BOOL)highlighted
{
    
}

- (void)setEmotion:(WBEmotion *)emotion
{
    _emotion = emotion;
    
    if (emotion.png) { // 有图片
        NSRange range = NSMakeRange(0, 3);
        NSString *prefix = [emotion.png substringWithRange:range];
        //判断是default还是lxh图片
        if ([prefix isEqualToString:@"lxh"]) {
            NSString *path = [[NSBundle mainBundle] pathForResource:@"EmotionIcons/lxh" ofType:nil];
            NSString *realImage = [emotion.png stringByDeletingPathExtension];
            [self setImage:[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@/%@@2x.png",path,realImage]] forState:UIControlStateNormal];
        }else{
            [self setImage:[UIImage imageNamed:emotion.png] forState:UIControlStateNormal];
            NSString *path = [[NSBundle mainBundle] pathForResource:@"EmotionIcons/default" ofType:nil];
            NSString *realImage = [emotion.png stringByDeletingPathExtension];
            [self setImage:[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@/%@@2x.png",path,realImage]] forState:UIControlStateNormal];
        }
    } else if (emotion.code) {
        // 是emoji表情,设置emoji
        [self setTitle:emotion.code.emoji forState:UIControlStateNormal];
        self.titleLabel.font = [UIFont systemFontOfSize:32];
    }

    
}






@end
