//
//  AddViewController.m
//  我的微博项目
//
//  Created by apple-jd37 on 15/10/20.
//  Copyright (c) 2015年 apple-jd37. All rights reserved.
//

#import "AddViewController.h"
#import "SendWBViewController.h"

#define buttonWidth (self.view.bounds.size.width - 120)/3
#define buttonHeight (self.view.bounds.size.height*1/6.0) - 30
@interface AddViewController ()
//@property (nonatomic,strong) UIView   *ContentView;
@property (nonatomic,strong) UIView  *view1;
@property (nonatomic,strong) UIView  *view2;
@end

@implementation AddViewController
- (UIView *)view1
{
    if (!_view1) {
        _view1 =[[UIView alloc] initWithFrame:CGRectMake(0,viewHeight , viewWidth, viewHeight/2.0+40)];
         _view1.alpha = 0;
    }
    return _view1;
}
- (UIView *)view2
{
    if (!_view2) {
        _view2 =[[UIView alloc] initWithFrame:CGRectMake(viewWidth,viewHeight/2.0-40 , viewWidth, viewHeight/2.0+40)];
        _view2.alpha = 0;
    }
    return _view2;
}
- (void)viewDidLoad {
    [super viewDidLoad];
     self.view.backgroundColor= [UIColor colorWithRed:240/255.0 green:240/255.0 blue:240/255.0 alpha:1];
    self.navigationController.navigationBar.hidden = YES;
    [self showFirstView];
    [self showSecondView];
}
//视图准备出现时调用
- (void)showFirstView
{
    //设置按钮图形
    UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(30, 30, buttonWidth, buttonWidth)];
    [button setImage:[UIImage imageNamed:@"tabbar_compose_idea"] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(sendMessage) forControlEvents:UIControlEventTouchUpInside];
    [self.view1 addSubview:button];
    UIButton *button2 = [[UIButton alloc] initWithFrame:CGRectMake(60+buttonWidth, 30, buttonWidth, buttonWidth)];
    [button2 setImage:[UIImage imageNamed:@"tabbar_compose_photo"] forState:UIControlStateNormal];
    [self.view1 addSubview:button2];
    UIButton *button3 = [[UIButton alloc] initWithFrame:CGRectMake(90+buttonWidth*2, 30, buttonWidth, buttonWidth)];
    [button3 setImage:[UIImage imageNamed:@"tabbar_compose_camera"] forState:UIControlStateNormal];
    [self.view1 addSubview:button3];
    UIButton *button4 = [[UIButton alloc] initWithFrame:CGRectMake(30, 2.5/5.0*self.view1.height, buttonWidth, buttonWidth)];
    [button4 setImage:[UIImage imageNamed:@"tabbar_compose_lbs"] forState:UIControlStateNormal];
    [self.view1 addSubview:button4];
    UIButton *button5 = [[UIButton alloc] initWithFrame:CGRectMake(60+buttonWidth, 2.5/5.0*self.view1.height, buttonWidth, buttonWidth)];
    [button5 setImage:[UIImage imageNamed:@"tabbar_compose_review"] forState:UIControlStateNormal];
    [self.view1 addSubview:button5];
    UIButton *button6 = [[UIButton alloc] initWithFrame:CGRectMake(90+buttonWidth*2, 2.5/5.0*self.view1.height, buttonWidth, buttonWidth)];
    [button6 setImage:[UIImage imageNamed:@"tabbar_compose_more"] forState:UIControlStateNormal];
    [button6 addTarget:self action:@selector(gotoSecond) forControlEvents:UIControlEventTouchUpInside];
    [self.view1 addSubview:button6];
    
    //设置lable图形
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(30, 30+buttonWidth, labelWidth, labelHeight)];
    label.text = @"文字";
    label.textAlignment = NSTextAlignmentCenter;
    label.alpha = 0.5;
    [self.view1 addSubview:label];
    UILabel *label2 = [[UILabel alloc] initWithFrame:CGRectMake(60+buttonWidth, 30+buttonWidth, labelWidth, labelHeight)];
    label2.text = @"相册";
    label2.textAlignment = NSTextAlignmentCenter;
    label2.alpha = 0.5;
    [self.view1 addSubview:label2];
    UILabel *label3 = [[UILabel alloc] initWithFrame:CGRectMake(90+buttonWidth*2, 30+buttonWidth, labelWidth, labelHeight)];
    label3.text = @"拍照";
    label3.textAlignment = NSTextAlignmentCenter;
    label3.alpha = 0.5;
    [self.view1 addSubview:label3];
    UILabel *label4 = [[UILabel alloc] initWithFrame:CGRectMake(30, 140+buttonWidth, labelWidth, labelHeight)];
    label4.text = @"签到";
    label4.textAlignment = NSTextAlignmentCenter;
    label4.alpha = 0.5;
    [self.view1 addSubview:label4];
    UILabel *label5 = [[UILabel alloc] initWithFrame:CGRectMake(60+buttonWidth, 140+buttonWidth, labelWidth, labelHeight)];
    label5.text = @"点评";
    label5.textAlignment = NSTextAlignmentCenter;
    label5.alpha = 0.5;
    [self.view1 addSubview:label5];
    UILabel *label6 = [[UILabel alloc] initWithFrame:CGRectMake(90+buttonWidth*2, 140+buttonWidth, labelWidth, labelHeight)];
    label6.text = @"更多";
    label6.textAlignment = NSTextAlignmentCenter;
    label6.alpha = 0.5;
    [self.view1 addSubview:label6];
    
    //设置X按钮
    UIButton *cancelButton = [[UIButton alloc] initWithFrame:CGRectMake(0, viewHeight/2, viewWidth, 40)];
    //    cancelButton.backgroundColor = [UIColor yellowColor];
    cancelButton.backgroundColor = [UIColor whiteColor];
    [cancelButton setImage:[UIImage imageNamed:@"timeline_icon_delete_highlighted"] forState:UIControlStateNormal];
    [cancelButton addTarget:self action:@selector(cancelAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view1 addSubview:cancelButton];
//    self.view1.backgroundColor = [UIColor redColor];
    //    self.ContentView = self.view1;
    [self.view addSubview:self.view1];
    
    [self animationView1];
}
- (void)showSecondView
{
    
    //设置按钮图形
    UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(30, 30, buttonWidth, buttonWidth)];
    [button setImage:[UIImage imageNamed:@"tabbar_compose_friend"] forState:UIControlStateNormal];
    [self.view2 addSubview:button];
    UIButton *button2 = [[UIButton alloc] initWithFrame:CGRectMake(60+buttonWidth, 30, buttonWidth, buttonWidth)];
    [button2 setImage:[UIImage imageNamed:@"tabbar_compose_voice"] forState:UIControlStateNormal];
    [self.view2 addSubview:button2];
    UIButton *button3 = [[UIButton alloc] initWithFrame:CGRectMake(90+buttonWidth*2, 30, buttonWidth, buttonWidth)];
    [button3 setImage:[UIImage imageNamed:@"tabbar_compose_shooting"] forState:UIControlStateNormal];
    [self.view2 addSubview:button3];
    UIButton *button4 = [[UIButton alloc] initWithFrame:CGRectMake(30, 2.5/5.0*self.view1.height, buttonWidth, buttonWidth)];
    [button4 setImage:[UIImage imageNamed:@"tabbar_compose_delete"] forState:UIControlStateNormal];
    [self.view2 addSubview:button4];
    UIButton *button5 = [[UIButton alloc] initWithFrame:CGRectMake(60+buttonWidth, 2.5/5.0*self.view1.height, buttonWidth, buttonWidth)];
    [button5 setImage:[UIImage imageNamed:@"tabbar_compose_weibo"] forState:UIControlStateNormal];
    [self.view2 addSubview:button5];
    
    
    //设置lable图形
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(30, 30+buttonWidth, labelWidth, labelHeight)];
    label.text = @"好友圈";
    label.textAlignment = NSTextAlignmentCenter;
    label.alpha = 0.5;
    [self.view2 addSubview:label];
    UILabel *label2 = [[UILabel alloc] initWithFrame:CGRectMake(60+buttonWidth, 30+buttonWidth, labelWidth, labelHeight)];
    label2.text = @"有声照片";
    label2.textAlignment = NSTextAlignmentCenter;
    label2.alpha = 0.5;
    [self.view2 addSubview:label2];
    UILabel *label3 = [[UILabel alloc] initWithFrame:CGRectMake(90+buttonWidth*2, 30+buttonWidth, labelWidth, labelHeight)];
    label3.text = @"秒拍";
    label3.textAlignment = NSTextAlignmentCenter;
    label3.alpha = 0.5;
    [self.view2 addSubview:label3];
    UILabel *label4 = [[UILabel alloc] initWithFrame:CGRectMake(30, 140+buttonWidth, labelWidth, labelHeight)];
    label4.text = @"定时删";
    label4.textAlignment = NSTextAlignmentCenter;
    label4.alpha = 0.5;
    [self.view2 addSubview:label4];
    UILabel *label5 = [[UILabel alloc] initWithFrame:CGRectMake(60+buttonWidth, 140+buttonWidth, labelWidth, labelHeight)];
    label5.text = @"长微博";
    label5.textAlignment = NSTextAlignmentCenter;
    label5.alpha = 0.5;
    [self.view2 addSubview:label5];
    
    
    //设置√按钮和X按钮
    UIButton *rightButton = [[UIButton alloc] initWithFrame:CGRectMake(0, viewHeight/2, viewWidth/2-1, 40)];
    rightButton.backgroundColor = [UIColor yellowColor];
    rightButton.backgroundColor = [UIColor whiteColor];
    [rightButton setImage:[UIImage imageNamed:@"tabbar_compose_background_icon_return"] forState:UIControlStateNormal];
    [rightButton addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view2 addSubview:rightButton];
    
    UIButton *cancelButton = [[UIButton alloc] initWithFrame:CGRectMake(viewWidth/2+1, viewHeight/2-1, viewWidth/2-1, 40)];
    cancelButton.backgroundColor = [UIColor blueColor];
    cancelButton.backgroundColor = [UIColor whiteColor];
    [cancelButton setImage:[UIImage imageNamed:@"timeline_icon_delete_highlighted"] forState:UIControlStateNormal];
    [cancelButton addTarget:self action:@selector(cancelAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view2 addSubview:cancelButton];
    
    [self.view addSubview:self.view2];
}

- (void)animationView1
{
    [UIView animateWithDuration:0.2 animations:^{
        self.view1.frame = CGRectMake(0, viewHeight/2.0-40, viewWidth, (viewHeight/2.0)+40);
        self.view1.alpha = 1;
        [self.view setNeedsDisplay];
    }];
//    [UIView animateWithDuration:1.5 delay:0 usingSpringWithDamping:0.4 initialSpringVelocity:0 options:UIViewAnimationOptionCurveEaseIn animations:^{
//        self.view1.transform = CGAffineTransformIdentity;
//    } completion:^(BOOL finished) {
//        self.view1.frame = CGRectMake(0, viewHeight/2.0-40, viewWidth, (viewHeight/2.0)+40);
//                self.view1.alpha = 1;
//                [self.view setNeedsDisplay];
//    }];
}
- (void)animationView2
{
    [UIView animateWithDuration:0.5 animations:^{
        self.view2.frame = CGRectMake(0, viewHeight/2.0-40, viewWidth, (viewHeight/2.0)+40);
        self.view2.alpha = 1;
        [self.view setNeedsDisplay];
    }];
}


- (void)gotoSecond
{
    [self.view1 setHidden:YES];
    [self.view2 setHidden:NO];
    [UIView animateWithDuration:0.3 animations:^{
        self.view2.frame = CGRectMake(0, viewHeight/2.0-40, viewWidth, (viewHeight/2.0)+40);
        self.view1.frame =CGRectMake(-viewWidth, viewHeight/2.0-40, viewWidth, (viewHeight/2.0)+40);
        self.view2.alpha = 1;
        [self.view setNeedsDisplay];
    }];
}
- (void)backAction
{
    [self.view2 setHidden:YES];
    [self.view1 setHidden:NO];
    [self showFirstView];
    [UIView animateWithDuration:0.3 animations:^{
        self.view1.frame = CGRectMake(0, viewHeight/2.0-40, viewWidth, (viewHeight/2.0)+40);
        self.view2.frame =CGRectMake(viewWidth, viewHeight/2.0-40, viewWidth, (viewHeight/2.0)+40);
        self.view1.alpha = 1;
        [self.view setNeedsDisplay];
    }];
}

- (void)cancelAction
{
    [UIView animateWithDuration:0.2 animations:^{
        self.view1.y = viewHeight;
    } completion:^(BOOL finished) {
        [self.view1 removeFromSuperview];
        [self.view2 removeFromSuperview];
        [self dismissViewControllerAnimated:YES completion:nil];
    }];
    
}
- (void)sendMessage
{
    SendWBViewController *vc = [[SendWBViewController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self cancelAction];
}

- (instancetype)init
{
    if (self = [super init]) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(receiveNotification:) name:@"goto" object:nil];
    }
    return self;
}
//通知一到达，自动执行此方法
-(void)receiveNotification:(NSNotification *)notification
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end
