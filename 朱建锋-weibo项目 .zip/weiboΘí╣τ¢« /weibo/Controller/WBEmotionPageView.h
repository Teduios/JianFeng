//
//  WBEmotionPageView.h
//  weibo
//
//  Created by apple-jd37 on 15/11/19.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WBEmotionPageView : UIView
/** 每一页的表情*/
@property (nonatomic,strong) NSArray  *emotions;

@end
