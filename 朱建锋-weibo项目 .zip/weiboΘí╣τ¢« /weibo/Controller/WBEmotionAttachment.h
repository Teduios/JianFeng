//
//  WBEmotionAttachment.h
//  weibo
//
//  Created by apple-jd37 on 15/11/21.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import <Foundation/Foundation.h>

@class WBEmotion;
@interface WBEmotionAttachment : NSTextAttachment

@property (nonatomic,strong) WBEmotion  *emotion;

@end
