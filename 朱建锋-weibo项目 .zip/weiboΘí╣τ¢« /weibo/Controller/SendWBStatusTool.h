//
//  SendWBStatusTool.h
//  weibo
//
//  Created by apple-jd37 on 15/11/16.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
    SendBtnTypePhtot=0,
    SendBtnTypeLock,
    SendBtnTypeTopic,
    SendBtnTypeFace,
    SendBtnTypeLongWb
}SendBtnType;

@class SendWBStatusTool;
@protocol SendWBStatusToolDelegate <NSObject>
@optional
- (void)setUpTool:(SendWBStatusTool *)tool forType:(SendBtnType)type;

@end

@interface SendWBStatusTool : UIView <SendWBStatusToolDelegate>
@property (nonatomic,weak) id<SendWBStatusToolDelegate>  delegate;
/** 是否要显示键盘按钮*/
@property (nonatomic,assign) BOOL  showKeyboardButton;

@end
