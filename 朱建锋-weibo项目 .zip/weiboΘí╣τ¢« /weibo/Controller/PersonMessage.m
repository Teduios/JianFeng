//
//  PersonMessage.m
//  weibo
//
//  Created by apple-jd37 on 15/11/23.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "PersonMessage.h"

@implementation PersonMessage

+ (NSDictionary *)replacedKeyFromPropertyName
{
    return @{@"Description":@"description"};
}

+ (instancetype)accessFromDict:(NSDictionary *)dict
{
    PersonMessage *personMessage = [[self alloc] init];
    personMessage.profile_image_url = dict[@"profile_image_url"];
    personMessage.name = dict[@"name"];
    personMessage.friends_count = [dict[@"friends_count"] intValue];
    personMessage.followers_count = [dict[@"followers_count"] intValue];
    personMessage.Description = dict[@"description"];
    personMessage.location = dict[@"location"];
    personMessage.domain = dict[@"domain"];
    personMessage.statuses_count = [dict[@"statuses_count"] intValue
    ];
    personMessage.verified = [dict[@"verified"] boolValue];
    
    return personMessage;
}

MJCodingImplementation

+ (PersonMessage *)acounted
{
    PersonMessage *message = [NSKeyedUnarchiver unarchiveObjectWithFile:PersonMessagePath];
    return message;
    
}

+ (void)saveAcount:(PersonMessage *)acount
{
    [NSKeyedArchiver archiveRootObject:acount toFile:PersonMessagePath];
}
@end
