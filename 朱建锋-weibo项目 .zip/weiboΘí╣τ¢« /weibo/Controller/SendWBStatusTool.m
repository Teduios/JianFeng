//
//  SendWBStatusTool.m
//  weibo
//
//  Created by apple-jd37 on 15/11/16.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "SendWBStatusTool.h"

@interface SendWBStatusTool ()
@property (nonatomic,weak) UIButton  *emotionButton;

@end

@implementation SendWBStatusTool

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"compose_toolbar_background"]];
        
        [self setUpImage:@"compose_toolbar_picture" HightLightImage:@"compose_toolbar_picture_highlighted" type:SendBtnTypePhtot];
         [self setUpImage:@"compose_mentionbutton_background" HightLightImage:@"compose_mentionbutton_background_highlighted" type:SendBtnTypeLock];
         [self setUpImage:@"compose_trendbutton_background" HightLightImage:@"compose_trendbutton_background_highlighted" type:SendBtnTypeTopic];
        self.emotionButton = [self setUpImage:@"compose_emoticonbutton_background" HightLightImage:@"compose_emoticonbutton_background_highlighted" type:SendBtnTypeFace];
         [self setUpImage:@"navigationbar_compose" HightLightImage:@"navigationbar_compose_highlighted" type:SendBtnTypeLongWb];
    }
    return self;
}
- (UIButton *)setUpImage:(NSString *)image HightLightImage:(NSString *)highImage type:(SendBtnType)type
{
    UIButton *btn = [[UIButton alloc] init];
    [btn setImage:[UIImage imageNamed:image] forState:UIControlStateNormal];
    [btn setImage:[UIImage imageNamed:highImage] forState:UIControlStateHighlighted];
    [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    btn.tag = type;
    [self addSubview:btn];
    return btn;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    NSInteger btnCount = self.subviews.count;
    CGFloat btnW = self.width/btnCount;
    CGFloat btnH = self.height;
    for (int i=0; i<btnCount; i++) {
        UIButton *btn = self.subviews[i];
        btn.x = i*btnW;
        btn.y=0;
        btn.width = btnW;
       btn.height= btnH;
    }
}

- (void)setShowKeyboardButton:(BOOL)showKeyboardButton
{
    NSString *image = @"compose_emoticonbutton_background";
    NSString *hightImage = @"compose_emoticonbutton_background_highlighted";
    if (showKeyboardButton) {
        //显示键盘图标
       image = @"compose_keyboardbutton_background";
       hightImage = @"compose_keyboardbutton_background_highlighted";
    }
    [self.emotionButton setImage:[UIImage imageNamed:image] forState:UIControlStateNormal];
    [self.emotionButton setImage:[UIImage imageNamed:hightImage] forState:UIControlStateHighlighted];
    
}

- (void)btnClick:(UIButton *)btn
{
    if ([self.delegate respondsToSelector:@selector(setUpTool:forType:)]) {
        [self.delegate setUpTool:self forType:btn.tag];
    }
}

@end





