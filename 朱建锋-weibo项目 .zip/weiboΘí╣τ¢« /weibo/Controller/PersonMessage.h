//
//  PersonMessage.h
//  weibo
//
//  Created by apple-jd37 on 15/11/23.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PersonMessage : NSObject

/** 用户头像地址*/
@property (nonatomic,strong) NSString  *profile_image_url;
/** 友好显示名称*/
@property (nonatomic,strong) NSString  *name;
/** 关注数*/
@property (nonatomic,assign) int  friends_count;
/** 粉丝数*/
@property (nonatomic,assign) int  followers_count;
/** 用户个人描述*/
@property (nonatomic,strong) NSString  *Description;
/** 用户所在地*/
@property (nonatomic,strong) NSString  *location;
/** 用户的个性化域名*/
@property (nonatomic,strong) NSString  *domain;
/** 微博数*/
@property (nonatomic,assign) int   statuses_count;
/** 是否是微博认证用户*/
@property (nonatomic,assign) Boolean  verified;

+ (instancetype)accessFromDict:(NSDictionary *)dict;
+ (PersonMessage *)acounted;
+ (void)saveAcount:(PersonMessage *)acount;


@end



