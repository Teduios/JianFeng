//
//  SendWBphotoView.m
//  weibo
//
//  Created by apple-jd37 on 15/11/17.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "SendWBphotoView.h"

@implementation SendWBphotoView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        _photos = [NSMutableArray array];
    }
    return self;
}

- (void)addPhoto:(UIImage *)photo
{
    UIImageView *photoView = [[UIImageView alloc] init];
    photoView.image = photo;
    [self addSubview:photoView];
    //存储照片
    [self.photos addObject:photo];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    // 设置图片的尺寸和位置
    NSUInteger count = self.subviews.count;
    int maxCol = 3;
    CGFloat imageMargin = 10;
    CGFloat imageWH = (self.bounds.size.width-4*imageMargin)/3;
    
    
    for (int i = 0; i<count; i++) {
        UIImageView *photoView = self.subviews[i];
        
        int col = i % maxCol;
        photoView.x = col * (imageWH + imageMargin)+imageMargin;
        
        int row = i / maxCol;
        photoView.y = row * (imageWH + imageMargin);
        photoView.width = imageWH;
        photoView.height = imageWH;
    }
}

@end
