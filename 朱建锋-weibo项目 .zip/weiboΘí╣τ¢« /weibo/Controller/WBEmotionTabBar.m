//
//  WBEmotionTabBar.m
//  weibo
//
//  Created by apple-jd37 on 15/11/17.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//
#import "WBEmotionButton.h"
#import "WBEmotionTabBar.h"

@interface WBEmotionTabBar ()

@property (nonatomic,weak) WBEmotionButton  *EmotionBtn;
@end

@implementation WBEmotionTabBar

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        //新建底部tabBar按钮
        [self setUpButtonTitle:@"最近" withTabBarType:WBEmotionTabBarTypeRecent];
        [self setUpButtonTitle:@"默认" withTabBarType:WBEmotionTabBarTypeDefault];
        [self setUpButtonTitle:@"Emoji" withTabBarType:WBEmotionTabBarTypeEmoji];
        [self setUpButtonTitle:@"浪小花" withTabBarType:WBEmotionTabBarTypeLxh];
    }
    return self;
}
- (WBEmotionButton *)setUpButtonTitle:(NSString *)title withTabBarType:(WBEmotionTabBarType)type
{
    WBEmotionButton *btn = [[WBEmotionButton alloc] init];
    [btn addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchDown];
    btn.tag = type;
    [btn setTitle:title forState:UIControlStateNormal];
    [self addSubview:btn];
    
//    if (type == WBEmotionTabBarTypeDefault) {
//        [self clickButton:btn];
//    }
    NSString *image = @"compose_emotion_table_mid_normal";
    NSString *selectImage = @"compose_emotion_table_mid_selected";
    if (self.subviews.count == 1) {
        image = @"compose_emotion_table_left_normal";
        selectImage = @"compose_emotion_table_left_selected";
    } else if (self.subviews.count == 4) {
        image = @"compose_emotion_table_right_normal";
        selectImage = @"compose_emotion_table_right_selected";
    }
   
    [btn setBackgroundImage:[UIImage imageNamed:image] forState:UIControlStateNormal];
    [btn setBackgroundImage:[UIImage imageNamed:selectImage] forState:UIControlStateDisabled];
//    [btn setBackgroundImage:[UIImage imageNamed:@"compose_emotion_table_left_selected"] forState:UIControlStateHighlighted];
    return btn;
    
}

- (void)setDelegate:(id<WBEmotionTabBarDelegate>)delegate
{
    _delegate = delegate;
    
    //选中默认的按钮时
    [self clickButton:(WBEmotionButton *)[self viewWithTag:WBEmotionTabBarTypeDefault]];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    NSInteger count = self.subviews.count;
    CGFloat btnW = self.width/count;
    for (int i=0; i<count; i++) {
        WBEmotionButton *btn = self.subviews[i];
        btn.x = i*btnW;
        btn.y = 0;
        btn.height = self.height;
        btn.width = btnW;

    }
    
}
- (void)clickButton:(WBEmotionButton *)btn
{
    self.EmotionBtn.enabled = YES;
    btn.enabled =NO;
    self.EmotionBtn = btn;
    
    if ([self.delegate respondsToSelector:@selector(emotionTabBar:didSelectButton:)]) {
        [self.delegate emotionTabBar:self didSelectButton:btn.tag];
    }
    
}

@end
