//
//  WBEmotion.m
//  weibo
//
//  Created by apple-jd37 on 15/11/18.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "WBEmotion.h"

@implementation WBEmotion

MJCodingImplementation

@end
