//
//  ImageViewCell.m
//  weibo
//
//  Created by apple-jd37 on 15/11/23.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "ImageViewCell.h"


@implementation ImageViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        UIImageView *imageView = [[UIImageView alloc] init];
        imageView.contentMode =UIViewContentModeScaleToFill;
        imageView.backgroundColor= [UIColor redColor];
        imageView.image = [UIImage imageNamed:@"guanggao"];
        [self.contentView addSubview:imageView];
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
