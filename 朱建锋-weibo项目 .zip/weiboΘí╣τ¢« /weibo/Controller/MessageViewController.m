//
//  MessageViewController.m
//  我的微博项目
//
//  Created by apple-jd37 on 15/10/17.
//  Copyright (c) 2015年 apple-jd37. All rights reserved.
//

#import "MessageViewController.h"
#import "Oauth_Account.h"
#import "OauthViewController.h"

@interface MessageViewController () <UITableViewDataSource,UITableViewDelegate>
@property (nonatomic) BOOL  isEnter;      //判断执行哪套方案
@property (nonatomic,strong) UIView  *firstView;  //第一套view
@property (nonatomic,strong) UITableView   *tableView;
@end

@implementation MessageViewController

- (instancetype)init
{
    if (self = [super init]) {
        [[UINavigationBar appearance] setTitleTextAttributes:@{NSForegroundColorAttributeName: [UIColor blackColor],NSFontAttributeName:[UIFont fontWithName:@"Baskerville" size:14.0]}];
        self.navigationItem.title = @"消息";
        
        Oauth_Account *acount = [NSKeyedUnarchiver unarchiveObjectWithFile:AccountPath];
        if (acount.recordMark == 1) {
            _isEnter = NO;
        }else{
            _isEnter = YES;
        }
        if (_isEnter == YES) {
            [self showFirstView];
        }else{
            [self showSecondView];
        }

    }
    return self;
}


- (void)showFirstView
{
    //定义第一个初始未登陆时的view
    UIView *firstView = [[UIView alloc] init];
    firstView.frame = CGRectMake(0, 0, viewWidth, viewHeight - 49-64);
    self.firstView = firstView;

    //设置初始view
    self.view.backgroundColor = [UIColor whiteColor];
    UIView *Dview = [[UIView alloc] initWithFrame:CGRectMake(0, 32, viewWidth, viewHeight*0.35)];
    //    Dview.backgroundColor = [UIColor redColor];
    UIImageView *homeImageView = [[UIImageView alloc] initWithFrame:CGRectMake(2.5/10.0*viewWidth, 0.09*viewHeight,1/2.0*viewWidth, 1/2.0*viewWidth)];    homeImageView.centerY = Dview.centerY;
    homeImageView.image = [UIImage imageNamed:@"visitordiscover_image_message"];
    //    homeImageView.backgroundColor = [UIColor yellowColor];
    homeImageView.alpha = 1;
    [Dview addSubview:homeImageView];
    [firstView addSubview:Dview];
    
    //设置文本Label
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0.1*viewWidth, textStartHeight, 0.8*viewWidth, 60)];
    label.textAlignment = NSTextAlignmentCenter;
    label.numberOfLines = 0;
    label.text = @"登陆后，别人评论你的微博，给你发消息，都会在这里收到通知";
    label.textColor = [UIColor blackColor];
    label.alpha = 0.5;
    label.font = [UIFont systemFontOfSize:14];
    [firstView addSubview:label];
    
    //设置两个按钮
    UIButton *registerButton = [[UIButton alloc] initWithFrame:CGRectMake(1/12.0*viewWidth, buttonStartHeight, buttonWidth, buttonHeight)];
    [registerButton setTintAdjustmentMode:UIViewTintAdjustmentModeNormal];
    [registerButton setTitle:@"注册" forState:UIControlStateNormal];
    [registerButton setBackgroundColor:[UIColor whiteColor]] ;
    [registerButton addTarget:self action:@selector(Login) forControlEvents:UIControlEventTouchUpInside];
    [registerButton setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal ] ;
    
    UIButton *registerButton2 = [[UIButton alloc] initWithFrame:CGRectMake(1/12.0*viewWidth+0.4*viewWidth+buttonMargin, buttonStartHeight, buttonWidth, buttonHeight)];
    [registerButton2 setTintAdjustmentMode:UIViewTintAdjustmentModeNormal];
    registerButton2.backgroundColor = [UIColor whiteColor];
    [registerButton2 addTarget:self action:@selector(Login) forControlEvents:UIControlEventTouchUpInside];
    [registerButton2 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal ] ;
    
    [registerButton2 setTitle:@"登陆" forState:UIControlStateNormal];
    
    [firstView addSubview:registerButton];
    [firstView addSubview:registerButton2];
    [self.view addSubview:firstView];
}


- (void)showSecondView
{
    [self.firstView removeFromSuperview];
    NSLog(@"%@",self.firstView);
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, viewWidth, viewHeight - 49-64)];
    self.tableView = tableView;
    tableView.tableFooterView = [[UIView alloc] init];
    tableView.backgroundColor = SetColor(225, 225, 228);
    tableView.dataSource = self;
    tableView.delegate = self;
    [self.view addSubview:tableView];

}

- (void)Login
{
    OauthViewController *vc = [OauthViewController new];
    [self presentViewController:vc animated:YES completion:nil];
}

#pragma mark - UITableViewDelegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 8;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Cell"];
    }
     cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    switch (indexPath.row) {
        case 0:
            cell.imageView.image = [UIImage imageNamed:@"messagescenter_at"];
            cell.textLabel.text = @"@我的";
            break;
        case 1:
            cell.imageView.image = [UIImage imageNamed:@"messagescenter_chat"];
            cell.textLabel.text = @"聊天";
            break;
        case 2:
            cell.imageView.image = [UIImage imageNamed:@"messagescenter_comments"];
            cell.textLabel.text = @"评论";
            break;
        case 3:
            cell.imageView.image = [UIImage imageNamed:@"messagescenter_good"];
            cell.textLabel.text = @"赞";
            break;
        case 4:
            cell.imageView.image = [UIImage imageNamed:@"messagescenter_groupchat_notice"];
            cell.textLabel.text = @"群聊";
            break;
        case 5:
            cell.imageView.image = [UIImage imageNamed:@"messagescenter_groupchat"];
            cell.textLabel.text = @"未关注人私信";
            break;
        case 6:
            cell.imageView.image = [UIImage imageNamed:@"messagescenter_messagebox"];
            cell.textLabel.text = @"关注人私信";
            break;
        case 7:
            cell.imageView.image = [UIImage imageNamed:@"messagescenter_subscription"];
            cell.textLabel.text = @"推送消息";
            break;
    }
    
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

@end
