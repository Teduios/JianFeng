//
//  PersonViewCell.m
//  weibo
//
//  Created by apple-jd37 on 15/11/23.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "PersonViewCell.h"
#import "PersonMessage.h"
#import "UIImageView+WebCache.h"

@interface PersonViewCell ()


@end
@implementation PersonViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.backgroundColor = SetColor(190, 223, 234);
        PersonMessage *message = [PersonMessage acounted];
        //头像
        
        UIImageView *icon = [[UIImageView alloc] initWithFrame:CGRectMake(20, 20, 50, 40)];
        [icon sd_setImageWithURL:[NSURL URLWithString:message.profile_image_url] placeholderImage:[UIImage imageNamed:@"avatar_default_small"]];
        [self addSubview:icon];
        //昵称
        CGSize nameLSize = [message.name sizeWithFont:WBUserNameFontSize];
        CGFloat nameLX = CGRectGetMaxX(icon.frame)+spaceWH;
        nameLSize.width +=5;
        UILabel *nameLable = [[UILabel alloc] initWithFrame:(CGRect){{nameLX,20},nameLSize}];
//        nameLable.font = [UIFont systemFontOfSize:14];
        nameLable.font = [UIFont fontWithName:@"Baskerville" size:15];
        nameLable.text = message.name;
        [self addSubview:nameLable];
        //会员图标
        CGFloat verifiX = CGRectGetMaxX(nameLable.frame)+spaceWH;
        UIImageView *verifiView = [[UIImageView alloc] initWithFrame:CGRectMake(verifiX, 20, 15, 15)];
        if (message.verified == YES) {
            verifiView.image = [UIImage imageNamed:@"common_icon_membership"];
        }else{
            verifiView.image = [UIImage imageNamed:@"common_icon_membership_expired"];
        }
        [self addSubview:verifiView];
        //简介
        CGFloat descriptionY = CGRectGetMaxY(nameLable.frame)+5;
        UILabel *descriptionL = [[UILabel alloc] initWithFrame:CGRectMake(nameLX, descriptionY, 180, 15)];
        descriptionL.text = message.Description;
        descriptionL.textColor = SetColor(123, 123,123);
        descriptionL.font = [UIFont fontWithName:@"Baskerville" size:11];
        [self addSubview:descriptionL];
        
    }
    return self;
}



- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
