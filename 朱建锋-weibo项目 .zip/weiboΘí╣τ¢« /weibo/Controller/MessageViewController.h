//
//  MessageViewController.h
//  我的微博项目
//
//  Created by apple-jd37 on 15/10/17.
//  Copyright (c) 2015年 apple-jd37. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessageViewController : UIViewController

@end
