//
//  TextViewCell.m
//  weibo
//
//  Created by apple-jd37 on 15/11/23.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "TextViewCell.h"

@implementation TextViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.width, 40)];
        UIButton *btn1 = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 150, 40)];
        [btn1 setTitle:@"#新罗送6S#" forState:UIControlStateNormal];
        [btn1 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
//        btn1.backgroundColor = [UIColor yellowColor];
        UIView *middle = [[UIView alloc] initWithFrame:CGRectMake(self.width/2-1, 5, 1, 30)];
        middle.backgroundColor = [UIColor grayColor];
        UIButton *btn2 = [[UIButton alloc] initWithFrame:CGRectMake(middle.x+10, 0, 150, 40)];
//        btn2.backgroundColor = [UIColor redColor];
        [btn2 setTitle:@"#解读微博财报#" forState:UIControlStateNormal];
         [btn2 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [view addSubview:btn1];
        [view addSubview:middle];
        [view addSubview:btn2];
        [self addSubview:view];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
