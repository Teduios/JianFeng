//
//  PersonalViewController.m
//  我的微博项目
//
//  Created by apple-jd37 on 15/10/17.
//  Copyright (c) 2015年 apple-jd37. All rights reserved.
//
#import "PersonalViewController.h"
#import "SettingViewController.h"
#import "Oauth_Account.h"
#import "PersonViewCell.h"
#import "PersonCountViewCell.h"
#import "OauthViewController.h"

@interface PersonalViewController () <UITableViewDataSource,UITableViewDelegate>
@property (nonatomic) BOOL  isEnter;      //判断执行哪套方案
@property (nonatomic,strong) UIView  *firstView;  //第一套view
@property (nonatomic,strong) UITableView   *tableView;
@end

@implementation PersonalViewController

- (instancetype)init
{
    if (self = [super init]) {
        [[UINavigationBar appearance] setTitleTextAttributes:@{NSForegroundColorAttributeName: [UIColor blackColor],NSFontAttributeName:[UIFont fontWithName:@"Baskerville" size:14.0]}];
        self.navigationItem.title = @"我";
        
        UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithTitle:@"设置" style:UIBarButtonItemStyleDone target:self action:@selector(login)];
        self.navigationItem.rightBarButtonItem = item;
        [item setTitleTextAttributes:@{NSForegroundColorAttributeName: [UIColor redColor],NSFontAttributeName:[UIFont fontWithName:@"Baskerville" size:14.0]} forState:UIControlStateNormal];
        
        Oauth_Account *acount = [NSKeyedUnarchiver unarchiveObjectWithFile:AccountPath];
        if (acount.recordMark == 1) {
            _isEnter = NO;
        }else{
            _isEnter = YES;
        }
        if (_isEnter == YES) {
            [self show];
        }else{
            [self showSecondView];
        }

        

    }
    return self;
}



- (void)show
{
    //定义第一个初始未登陆时的view
    UIView *firstView = [[UIView alloc] init];
    firstView.frame = CGRectMake(0, 0, viewWidth, viewHeight - 49-64);
    self.firstView = firstView;
    
    //设置view
    self.view.backgroundColor = [UIColor whiteColor];
    UIView *Dview = [[UIView alloc] initWithFrame:CGRectMake(0, 32, viewWidth, viewHeight*0.35)];
    //    Dview.backgroundColor = [UIColor redColor];
    UIImageView *homeImageView = [[UIImageView alloc] initWithFrame:CGRectMake(2.5/10.0*viewWidth, 0.09*viewHeight,1/2.0*viewWidth, 1/2.0*viewWidth)];
    homeImageView.centerY = Dview.centerY;
    homeImageView.image = [UIImage imageNamed:@"visitordiscover_image_profile"];
    homeImageView.alpha = 1;
    [Dview addSubview:homeImageView];
    [firstView addSubview:Dview];
    
    //设置文本Label
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0.1*viewWidth, textStartHeight, 0.8*viewWidth, 60)];
    label.textAlignment = NSTextAlignmentCenter;
    label.numberOfLines = 0;
    label.text = @"登陆后，你的微博、相册、个人资料会显示在这里，展示给他们";
    label.textColor = [UIColor blackColor];
    label.alpha = 0.5;
    label.font = [UIFont systemFontOfSize:14];
    [firstView addSubview:label];
    
    //设置两个按钮
    UIButton *registerButton = [[UIButton alloc] initWithFrame:CGRectMake(1/12.0*viewWidth, buttonStartHeight, buttonWidth, buttonHeight)];
    [registerButton setTintAdjustmentMode:UIViewTintAdjustmentModeNormal];
    [registerButton setTitle:@"注册" forState:UIControlStateNormal];
    [registerButton addTarget:self action:@selector(Login) forControlEvents:UIControlEventTouchUpInside];
    [registerButton setBackgroundColor:[UIColor whiteColor]] ;
    [registerButton setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal ] ;
    
    UIButton *registerButton2 = [[UIButton alloc] initWithFrame:CGRectMake(1/12.0*viewWidth+0.4*viewWidth+buttonMargin, buttonStartHeight, buttonWidth, buttonHeight)];
    [registerButton2 setTintAdjustmentMode:UIViewTintAdjustmentModeNormal];
    registerButton2.backgroundColor = [UIColor whiteColor];
    [registerButton2 addTarget:self action:@selector(Login) forControlEvents:UIControlEventTouchUpInside];
    [registerButton2 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal ] ;
    
    [registerButton2 setTitle:@"登陆" forState:UIControlStateNormal];
    
    [firstView addSubview:registerButton];
    [firstView addSubview:registerButton2];
    [self.view addSubview:firstView];

}

- (void)showSecondView
{
    [self.firstView removeFromSuperview];
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, viewWidth, viewHeight - 49-64) style:UITableViewStyleGrouped];
    self.tableView = tableView;
    tableView.sectionFooterHeight = 1.0;
//    tableView.tableFooterView = [[UIView alloc] init];
    [tableView registerClass:[PersonViewCell class] forCellReuseIdentifier:@"PersonCell"];
    [tableView registerClass:[PersonCountViewCell class] forCellReuseIdentifier:@"PersonCount"];
    tableView.dataSource = self;
    tableView.delegate = self;
    [self.view addSubview:tableView];
}

- (void)Login
{
    OauthViewController *vc = [OauthViewController new];
    [self presentViewController:vc animated:YES completion:nil];
}

- (void)login
{
    [self.navigationController pushViewController:[SettingViewController new] animated:YES];
}

#pragma mark - UITableViewDelegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 6;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    switch (section) {
        case 0:
            return 2;
            break;
        case 1:
            return 3;
            break;
        case 2:
            return 3;
            break;
        case 3:
            return 2;
            break;
        case 4:
            return 1;
            break;
        case 5:
            return 1;
            break;

        default:
            return 0;
            break;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Cell"];
    }
    PersonViewCell *cell1 = [tableView dequeueReusableCellWithIdentifier:@"PersonCell"];
    PersonCountViewCell *cell2 = [tableView dequeueReusableCellWithIdentifier:@"PersonCount"];
    switch (indexPath.section) {
        case 0:
            if (indexPath.row == 0) {
                cell1.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
                return cell1;
            }else{
                return cell2;
            }
            break;
        case 1:
            if (indexPath.row == 0) {
                cell.imageView.image = [UIImage imageNamed:@"message_creategroup_portrait"];
                cell.textLabel.text = @"一起来聊聊";
            }else if(indexPath.row == 1){
                cell.imageView.image = [UIImage imageNamed:@"feedgroup_timeline_icon_message"];
                cell.textLabel.text = @"联系人";
            }else{
                cell.imageView.image = [UIImage imageNamed:@"message_addfansgroup"];
                cell.textLabel.text = @"兴趣组";
            }
            break;
        case 2:
            if (indexPath.row == 0) {
                cell.imageView.image = [UIImage imageNamed:@"message_creatchat"];
                cell.textLabel.text = @"分组聊天";
            }else if(indexPath.row == 1){
                cell.imageView.image = [UIImage imageNamed:@"contacts_findfriends_icon"];
                cell.textLabel.text = @"加好友";
            }else{
                cell.imageView.image = [UIImage imageNamed:@"radar_icon_tv_selected"];
                cell.textLabel.text = @"看看";
            }
            break;
        case 3:
            if (indexPath.row == 0) {
                cell.imageView.image = [UIImage imageNamed:@"contact_miyou_icon"];
                cell.textLabel.text = @"关于我";
            }else{
                cell.imageView.image = [UIImage imageNamed:@"rim_timeline_icon_loc"];
                cell.textLabel.text = @"地标建筑";
            }
            break;
        case 4:
            cell.imageView.image = [UIImage imageNamed:@"radar_card_guide_hot"];
            cell.textLabel.text = @"引领时尚";
            break;
        case 5:
            cell.imageView.image = [UIImage imageNamed:@"noticelist_invite_praise"];
            cell.textLabel.text = @"赞一赞";
            break;
        default:
            break;
    }
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0 && indexPath.row == 0) {
        return 80;
    }else{
        return 40;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 10;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
}


@end
