//
//  SettingViewController.m
//  weibo
//
//  Created by apple-jd37 on 15/10/23.
//  Copyright (c) 2015年 apple-jd37. All rights reserved.
//

#import "SettingViewController.h"

@interface SettingViewController ()

@end

@implementation SettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.bounces = NO;
    self.navigationItem.title = @"设置";
    self.view.backgroundColor= [UIColor colorWithRed:240/255.0 green:240/255.0 blue:240/255.0 alpha:1];

    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 40, 40)];
    UIButton *button1 = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 40, 40)];
    [button1 addTarget:self action:@selector(funcionaa) forControlEvents:UIControlEventTouchUpInside];
    [button1 setBackgroundImage:[UIImage imageNamed:@"userinfo_tabicon_back"] forState:UIControlStateNormal];
    [button1 setBackgroundImage:[UIImage imageNamed:@"userinfo_tabicon_back_highlighted"] forState:UIControlStateHighlighted];
    [view addSubview:button1];
    UIBarButtonItem *item1 = [[UIBarButtonItem alloc] initWithCustomView:view];
    self.navigationItem.leftBarButtonItem = item1;

}
- (void)funcionaa
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return 2;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"Cell"];
    
    if (indexPath.row ==0) {
        cell.textLabel.text = @"通用设置";
    }
    else{
        cell.textLabel.text = @"关于微博";
        UIImageView *imageview = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"visitordiscover_feed_helper"]];
        imageview.height = 30;
         NSLog(@"%@",NSStringFromCGSize(imageview.bounds.size));
        cell.accessoryView =imageview;
    }
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 20;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 300;
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    UIView *view = [[UIView alloc] init];
//    view.backgroundColor = [UIColor yellowColor];
    UILabel *label = [UILabel new];
    label.text = @"在这里设置你喜欢的阅读环境，让你在微博中的体验更舒心";
    label.frame = CGRectMake(0.2*viewWidth, 100, 0.6*viewWidth, 50);
    label.numberOfLines = 0;
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = [UIColor blackColor];
    label.alpha = 0.5;
    label.font = [UIFont systemFontOfSize:14];
    [view addSubview:label];
    return view;
}






@end
