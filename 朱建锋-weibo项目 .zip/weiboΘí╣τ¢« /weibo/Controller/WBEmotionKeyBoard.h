//
//  WBEmotionKeyBoard.h
//  weibo
//
//  Created by apple-jd37 on 15/11/17.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WBEmotionKeyBoard : UIView

@end
