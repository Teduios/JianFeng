//
//  WBEmotionTextView.m
//  weibo
//
//  Created by apple-jd37 on 15/11/20.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "WBEmotionTextView.h"
#import "WBEmotion.h"
#import "WBEmotionAttachment.h"

@implementation WBEmotionTextView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        
    }
    return self;
}

- (void)insertEmotion:(WBEmotion *)emotion
{
    /**
     selectedRange :
     1.本来是用来控制textView的文字选中范围
     2.如果selectedRange.length为0，selectedRange.location就是textView的光标位置
     
     关于textView文字的字体
     1.如果是普通文字（text），文字大小由textView.font控制
     2.如果是属性文字（attributedText），文字大小不受textView.font控制，应该利用NSMutableAttributedString的- (void)addAttribute:(NSString *)name value:(id)value range:(NSRange)range;方法设置字体
     **/

    if (emotion.code) {
        //emoji表情插入
        [self insertText:emotion.code.emoji];
    }else if(emotion.png) {
        //加载图片
        WBEmotionAttachment *attch = [[WBEmotionAttachment alloc] init];
        //定义图片名称
        
//        attch.image = [UIImage imageNamed:emotion.png];
        //传递模型
        attch.emotion = emotion;
      
       //设置图片尺寸
        CGFloat attchWH = self.font.lineHeight;
        attch.bounds = CGRectMake(0, -4, attchWH, attchWH);
        //根据附近创建一个属性文字
        NSAttributedString *imageStr = [NSAttributedString attributedStringWithAttachment:attch];
        //插入属性文字到光标位置
        [self insertAttributeText:imageStr];
        
        //设置字体
        NSMutableAttributedString *text = [[NSMutableAttributedString alloc] initWithAttributedString:self.attributedText];
        [text addAttribute:NSFontAttributeName value:self.font range:NSMakeRange(0, text.length)];
       
    }

}

- (NSString *)fullText
{
    NSMutableString *fullText = [NSMutableString string];
    //遍历所有的属性文字（图片、emoji、普通文字）
    [self.attributedText enumerateAttributesInRange:NSMakeRange(0, self.attributedText.length) options:0 usingBlock:^(NSDictionary<NSString *,id> * _Nonnull attrs, NSRange range, BOOL * _Nonnull stop) {
        //如果是图片表情
        WBEmotionAttachment *attch = attrs[@"NSAttachment"];
        if (attch) {
            //图片
            [fullText appendString:attch.emotion.chs];
        }else{
            //emoji、普通文本
            NSAttributedString *str = [self.attributedText attributedSubstringFromRange:range];
            [fullText appendString:str.string];
        }
    }];
    return fullText;
}





@end
