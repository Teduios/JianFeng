//
//  WBEmotionPageView.m
//  weibo
//
//  Created by apple-jd37 on 15/11/19.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "WBEmotionPageView.h"
#import "WBEmotionNoHL.h"
#import "WBEmotionTool.h"
#import "WBEmotion.h"

@interface WBEmotionPageView  ()
//删除按钮
@property (nonatomic,weak) UIButton  *deleteButton;
@end

@implementation WBEmotionPageView



- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        UIButton *deleteButton = [[UIButton alloc] init];
        [deleteButton setImage:[UIImage imageNamed:@"compose_emotion_delete_highlighted"] forState:UIControlStateHighlighted];
        [deleteButton setImage:[UIImage imageNamed:@"compose_emotion_delete"] forState:UIControlStateNormal];
        [deleteButton addTarget:self action:@selector(deleteClick) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:deleteButton];
        self.deleteButton = deleteButton;
    }
    return self;
}

- (void)setEmotions:(NSArray *)emotions
{
    _emotions = emotions;
    
    NSUInteger count = emotions.count;
    
    for (int i=0; i<count; i++) {
        WBEmotionNoHL *btn = [[WBEmotionNoHL alloc ] init];
        [self addSubview:btn];
      
        btn.emotion = emotions[i];

        
        [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    CGFloat inset = 10;
    CGFloat btnW = (self.width - 2*inset)/7;
    CGFloat btnH = (self.height - inset)/3;
    NSUInteger count = self.emotions.count;
    for (int i = 0; i<count; i++) {
        UIButton *btn = self.subviews[i+1];
        btn.width =btnW;
        btn.height = btnH;
        btn.x = inset + (i%7)*btnW;
        btn.y = inset + (i/7)*btnH;
  
    }
    self.deleteButton.width = btnW;
    self.deleteButton.height = btnH;
    self.deleteButton.y = self.height - btnH;
    self.deleteButton.x = self.width - inset - btnW;
}

#pragma mark - 按钮点击事件

/**
 *  点击删除
 */
- (void)deleteClick
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"EmotionDelete" object:nil];
}

/**
 *  选中某个表情，发出通知
 */
- (void)btnClick:(WBEmotionNoHL *)btn
{
    //先将这个表情存进沙盒
    [WBEmotionTool addRecentEmotion:btn.emotion];
    //发出通知
    WBEmotion *emotion = btn.emotion;
    NSMutableDictionary *userInfo = [NSMutableDictionary dictionary];
    userInfo[@"selectedEmotion"] =emotion;
    [[NSNotificationCenter defaultCenter] postNotificationName:@"EmotionDidNotification" object:nil userInfo:userInfo];
    
}



@end








