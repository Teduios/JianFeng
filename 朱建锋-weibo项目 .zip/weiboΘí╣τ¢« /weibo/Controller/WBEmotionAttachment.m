//
//  WBEmotionAttachment.m
//  weibo
//
//  Created by apple-jd37 on 15/11/21.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "WBEmotionAttachment.h"
#import "WBEmotion.h"

@implementation WBEmotionAttachment

- (void)setEmotion:(WBEmotion *)emotion
{
    _emotion = emotion;
    NSString *imageName = emotion.png;
    
    NSRange range = NSMakeRange(0, 3);
    NSString *prefix = [emotion.png substringWithRange:range];
    if ([prefix isEqualToString:@"lxh"]) {
        
        NSString *path = [[NSBundle mainBundle] pathForResource:@"EmotionIcons/lxh" ofType:nil];
        NSString *realImage = [imageName stringByDeletingPathExtension];
        
        self.image =[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@/%@@2x.png",path,realImage]];
    }else{
        NSString *path = [[NSBundle mainBundle] pathForResource:@"EmotionIcons/default" ofType:nil];
        NSString *realImage = [emotion.png stringByDeletingPathExtension];
        self.image =[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@/%@@2x.png",path,realImage]];
    }

}

@end
