//
//  DiscoverViewController.m
//  我的微博项目
//
//  Created by apple-jd37 on 15/10/17.
//  Copyright (c) 2015年 apple-jd37. All rights reserved.
//

#import "DiscoverViewController.h"
#import "ImageViewCell.h"
#import "TextViewCell.h"
#import "OauthViewController.h"

@interface DiscoverViewController () <UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate,UISearchResultsUpdating>
//增加属性：用于记录搜索控制器
@property (nonatomic,strong) UISearchController  *searchController;

@end

@implementation DiscoverViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[UINavigationBar appearance] setTitleTextAttributes:@{NSForegroundColorAttributeName: [UIColor blackColor],NSFontAttributeName:[UIFont fontWithName:@"Baskerville" size:14.0]}];
    self.navigationItem.title = @"发现";
    self.tableView.sectionFooterHeight = 1.0;
    self.tableView.bounces = NO;
    [self.tableView registerClass:[ImageViewCell class] forCellReuseIdentifier:@"Image"];
    [self.tableView registerClass:[TextViewCell class] forCellReuseIdentifier:@"Text"];
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithTitle:@"登陆" style:UIBarButtonItemStyleDone target:self action:@selector(login)];
    self.navigationItem.rightBarButtonItem = item;
    [item setTitleTextAttributes:@{NSForegroundColorAttributeName: [UIColor redColor],NSFontAttributeName:[UIFont fontWithName:@"Baskerville" size:14.0]} forState:UIControlStateNormal];
    
    //创建用于展示搜索结果的表VC实例
       //设置搜索框
    self.searchController = [[UISearchController alloc] initWithSearchResultsController:nil];
    //设置自适应
    self.searchController.searchBar.frame = CGRectMake(0, 64, viewWidth, 50);
    self.searchController.hidesNavigationBarDuringPresentation=NO;
//    self.searchController.dimsBackgroundDuringPresentation = NO;
    // 设置搜索控制器的结果更新代理对象
    self.searchController.searchResultsUpdater = self;
    self.searchController.searchBar.delegate = self;
    // 设置搜索条中的分段类别
    self.searchController.searchBar.scopeButtonTitles = @[@"搜人",@"搜微博",@"搜其他"];
    
    // 允许在当前界面上切换展示数据的上下文对象
    // 允许从红色table切换为展示绿色的table
    self.definesPresentationContext = YES;
    
    self.tableView.tableHeaderView = self.searchController.searchBar;
    
    [self showTableHeaderView];
}

- (void)login{
    OauthViewController *vc = [OauthViewController new];
    [self presentViewController:vc animated:YES completion:nil];

}

- (void)showTableHeaderView
{
    
    
}

#pragma mark - UISearchBarDelegate

- (void)searchBar:(UISearchBar *)searchBar selectedScopeButtonIndexDidChange:(NSInteger)selectedScope
{
    [self updateSearchResultsForSearchController:self.searchController];
}
- (void)updateSearchResultsForSearchController:(UISearchController *)searchController
{
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UITableViewDelegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView;
{
    return 5;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    switch (section) {
        case 0:
            return 1;
            break;
       case 1:
            return 2;
            break;
        case 2:
            return 2;
            break;
        case 3:
            return 4;
            break;
        case 4:
            return 6;
            break;
        default:
            return 0;
            break;
    }
}


 - (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

     UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
     if (!cell) {
         cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Cell"];
     }
     ImageViewCell *cell2 = [tableView dequeueReusableCellWithIdentifier:@"Image" ];
     TextViewCell *cell1 = [tableView dequeueReusableCellWithIdentifier:@"Text"];
     
     switch (indexPath.section) {
         case 0:
             return cell2;
             break;
         case 1:
             if (indexPath.row==0) {
                 
                 return cell1;
             }else {
                 return cell1;

             }
             break;
         case 2:
             if (indexPath.row == 0) {
                 cell.imageView.image = [UIImage imageNamed:@"radar_card_guide_hot"];
                 cell.textLabel.text = @"热门微博";
             }else{
                 cell.imageView.image = [UIImage imageNamed:@"poi_icon_myplace"];
                 cell.textLabel.text = @"找人";
             }
             break;
         case 3:
             switch (indexPath.row) {
                 case 0:
                     cell.imageView.image = [UIImage imageNamed:@"health_data_icon_run"];
                     cell.textLabel.text = @"奔跑2015";
                     break;
                 case 1:
                     cell.imageView.image = [UIImage imageNamed:@"camera_video_more"];
                     cell.textLabel.text = @"秒拍";
                     break;
                 case 2:
                     cell.imageView.image = [UIImage imageNamed:@"contact_miyou_icon"];
                     cell.textLabel.text = @"关心世界";
                     break;
                 case 3:
                     cell.imageView.image = [UIImage imageNamed:@"rim_timeline_icon_loc"];
                     cell.textLabel.text = @"周边";
                     break;
                 default:
                     break;
             }
             break;
         case 4:
             switch (indexPath.row) {
                 case 0:
                     cell.imageView.image = [UIImage imageNamed:@"tabbar_compose_book"];
                     cell.textLabel.text = @"订阅";
                     break;
                 case 1:
                     cell.imageView.image = [UIImage imageNamed:@"radar_icon_car_selected"];
                     cell.textLabel.text = @"微博快车";
                     break;
                 case 2:
                     cell.imageView.image = [UIImage imageNamed:@"profile_button_video_play"];
                     cell.textLabel.text = @"视频";
                     break;
                 case 3:
                     cell.imageView.image = [UIImage imageNamed:@"noticelist_invite_praise"];
                     cell.textLabel.text = @"表赞";
                     break;
                 case 4:
                     cell.imageView.image = [UIImage imageNamed:@"noticelist_invite_hi"];
                     cell.textLabel.text = @"打招呼";
                     break;
                 case 5:
                     cell.imageView.image = [UIImage imageNamed:@"message_addfansgroup"];
                     cell.textLabel.text = @"加好友";
                     break;
                     
                 default:
                     break;
             }
             break;
             
         default:
             return 0;
             break;
     }
     
     return cell;

 }

- (CGFloat )tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        return 100;
    }
    return 40;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    switch (section) {
        case 0:
            return 10;
            break;
        case 1:
            return 10;
            break;
        case 2:
            return 10;
            break;
        case 3:
            return 10;
            break;
        case 4:
            return 10;
            break;
        default:
            return 10;
            break;
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0;
}

@end
