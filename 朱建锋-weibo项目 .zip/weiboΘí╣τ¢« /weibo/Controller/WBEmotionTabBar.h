//
//  WBEmotionTabBar.h
//  weibo
//
//  Created by apple-jd37 on 15/11/17.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
    WBEmotionTabBarTypeRecent,
    WBEmotionTabBarTypeDefault,
    WBEmotionTabBarTypeEmoji,
    WBEmotionTabBarTypeLxh
}WBEmotionTabBarType;

@class WBEmotionTabBar;

@protocol WBEmotionTabBarDelegate <NSObject>
@optional
- (void)emotionTabBar:(WBEmotionTabBar *)tabBar didSelectButton:(WBEmotionTabBarType)type;

@end

@interface WBEmotionTabBar : UIView
@property (nonatomic,weak) id<WBEmotionTabBarDelegate>  delegate;


@end
