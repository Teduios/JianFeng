//
//  WBEmotionKeyBoard.m
//  weibo
//
//  Created by apple-jd37 on 15/11/17.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "WBEmotionKeyBoard.h"
#import "WBEmotionTabBar.h"
#import "WBEmotionListView.h"
#import "WBEmotionTool.h"
#import "WBEmotion.h"

@interface WBEmotionKeyBoard () <WBEmotionTabBarDelegate>

@property (nonatomic,weak)  WBEmotionTabBar *keyboardTabbar;
@property (nonatomic,weak)  WBEmotionListView *showView;
@property (nonatomic,strong) WBEmotionListView  *recentView;
@property (nonatomic,strong) WBEmotionListView  *defaultView;
@property (nonatomic,strong) WBEmotionListView  *emojiView;
@property (nonatomic,strong) WBEmotionListView  *lxhView;

@end
@implementation WBEmotionKeyBoard

#pragma mark - 懒加载

- (WBEmotionListView *)recentView
{
    if (!_recentView) {
        _recentView = [[WBEmotionListView alloc] init];
        //读取沙盒数据到最近的表情中
         self.recentView.emotions = [WBEmotionTool recentEmotions];
    }
    return _recentView;
}
- (WBEmotionListView *)defaultView
{
    if (!_defaultView) {
        _defaultView = [[WBEmotionListView alloc] init];
//        _defaultView.backgroundColor = [UIColor greenColor];
        NSString *path = [[NSBundle mainBundle] pathForResource:@"EmotionIcons/default/info.plist" ofType:nil];
        self.defaultView.emotions = [WBEmotion objectArrayWithKeyValuesArray:[NSArray arrayWithContentsOfFile:path]];
    }
    return _defaultView;
}
- (WBEmotionListView *)emojiView
{
    if (!_emojiView) {
        _emojiView = [[WBEmotionListView alloc] init];
//        _emojiView.backgroundColor = [UIColor yellowColor];
        NSString *path = [[NSBundle mainBundle] pathForResource:@"EmotionIcons/emoji/info.plist" ofType:nil];
        self.emojiView.emotions = [WBEmotion objectArrayWithKeyValuesArray:[NSArray arrayWithContentsOfFile:path]];
    }
    return _emojiView;
}
- (WBEmotionListView *)lxhView
{
    if (!_lxhView) {
        _lxhView = [[WBEmotionListView alloc] init];
//        _lxhView.backgroundColor = [UIColor redColor];
        NSString *path = [[NSBundle mainBundle] pathForResource:@"EmotionIcons/lxh/info.plist" ofType:nil];
        self.lxhView.emotions = [WBEmotion objectArrayWithKeyValuesArray:[NSArray arrayWithContentsOfFile:path]];
    }
    return _lxhView;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {

        
        //创建表情键盘底部tabBar
        WBEmotionTabBar *keyboardTabbar = [[WBEmotionTabBar alloc] init];
        keyboardTabbar.delegate = self;
        [self addSubview:keyboardTabbar];
         self.keyboardTabbar = keyboardTabbar;
        //表情选中的通知
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(emtionDidSelect) name:@"EmotionDidNotification" object:nil];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    //表情内容
    self.showView.x = self.showView.y = 0;
    self.showView.height = self.keyboardTabbar.y;
    self.showView.width = self.width;
    
    self.keyboardTabbar.x = 0;
    self.keyboardTabbar.height=37;
    self.keyboardTabbar.width = self.width;
    self.keyboardTabbar.y = self.height-self.keyboardTabbar.height;


}

- (void)emotionTabBar:(WBEmotionTabBar *)tabBar didSelectButton:(WBEmotionTabBarType)type
{
    //移除contentView之前显示的控件
    [self.showView removeFromSuperview];
    
    switch (type) {
        case WBEmotionTabBarTypeRecent:{
            [self addSubview:self.recentView];
            break;
        }
        case WBEmotionTabBarTypeDefault:{
           [self addSubview:self.defaultView];
            break;
        }
        case WBEmotionTabBarTypeEmoji: {
            [self addSubview:self.emojiView];
            break;
        }
        case WBEmotionTabBarTypeLxh: {
           [self addSubview:self.lxhView];
            break;
        }
    }
    self.showView = [self.subviews lastObject];
    
}

- (void)emtionDidSelect
{
    self.recentView.emotions  = [WBEmotionTool recentEmotions];
    //重新计算子控件的frame
    [self setNeedsLayout];
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


@end
