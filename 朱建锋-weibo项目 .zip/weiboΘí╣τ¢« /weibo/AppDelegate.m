//
//  AppDelegate.m
//  我的微博项目
//
//  Created by apple-jd37 on 15/10/14.
//  Copyright (c) 2015年 apple-jd37. All rights reserved.
//

#import "AppDelegate.h"
#import "newFeatureViewController.h"
#import "MyHomeTabBarViewController.h"
#import "SDWebImageManager.h"

@interface AppDelegate ()
@property (nonatomic) BOOL  isClick;
@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor = [UIColor whiteColor];
    
    NSString *key = @"CFBundleVersion";
    NSDictionary *infoDict = [[NSBundle mainBundle] infoDictionary];
    //获得当前版本
    NSString *currentVerson = infoDict[key];
    //获得现在运行版本（已经运行的版本需要持久化处理，通过存储在userDefault中）
    NSString *runVerson = [[NSUserDefaults standardUserDefaults] stringForKey:key];
    
    //从沙盒中取出_isClick的值
    _isClick = [[[NSUserDefaults standardUserDefaults] stringForKey:@"isDone"]boolValue];
    
    //如果没运行过，或者版本号不一致,或者没有点击“进入微博”
    if (runVerson == nil || ![runVerson isEqualToString:currentVerson ] || _isClick==NO) {
        //运行欢迎界面
        self.window.rootViewController = [[newFeatureViewController alloc] init];
        //把当前版本号存进沙盒中
        [[NSUserDefaults standardUserDefaults] setValue:currentVerson forKey:key];
        
    }
    else{ //直接进入Myhome中：
            self.window.rootViewController = [[MyHomeTabBarViewController alloc] init];
    }
    //把_isClick的值存入沙盒中
    [self.window makeKeyAndVisible];
    return YES;
}

- (instancetype)init
{
    if (self == [super init]) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(receiveNotification:) name:@"EnterMyHome" object:nil];
    }
    return self;
}

- (void)receiveNotification:(NSNotification *)notification
{
    NSDictionary *userInfo = notification.userInfo;
    _isClick = [userInfo[@"isDone"] boolValue];
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

/**
 *  app进入后台时调用
 */
- (void)applicationDidEnterBackground:(UIApplication *)application {
    
  __block  UIBackgroundTaskIdentifier task = [application beginBackgroundTaskWithExpirationHandler:^{
        [application endBackgroundTask:task];
    }];
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}
/**
 *  记住：使用了SDWebImage后，要在appDelegate里面加入以下代码
 */
- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application
{
    SDWebImageManager *manager = [SDWebImageManager sharedManager];
    //取消异步下载
    [manager cancelAll];
    //清除内存中所有图片
    [manager.imageCache clearMemory];
}

//- (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notif {
//    application.applicationIconBadgeNumber = notif.applicationIconBadgeNumber-1;
//}

@end
