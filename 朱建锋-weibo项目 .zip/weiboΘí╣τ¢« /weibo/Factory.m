//
//  Factory.m
//  weibo
//
//  Created by apple-jd37 on 15/11/23.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "Factory.h"

@implementation Factory

+ (void)addBackItemToVC:(UIViewController *)vc
{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setTitle:@"返回" forState:UIControlStateNormal];
    btn.frame = CGRectMake(0, 0, 45, 45);
    [btn addTarget:self action:@selector(gotoBack:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithCustomView:btn];
    vc.navigationItem.leftBarButtonItem = item;
}

- (void)gotoBack:(UIViewController *)vc
{
    [vc.navigationController popViewControllerAnimated:YES];
}

@end
