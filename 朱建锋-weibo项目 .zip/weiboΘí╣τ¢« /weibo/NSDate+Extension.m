//
//  NSDate+Extension.m
//  weibo
//
//  Created by apple-jd37 on 15/11/12.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "NSDate+Extension.h"

@implementation NSDate (Extension)
//判断是否是今年
- (BOOL)isThisYear
{
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *dateCmp = [calendar components:NSCalendarUnitYear fromDate:self];
     NSDateComponents *dateNow = [calendar components:NSCalendarUnitYear fromDate:[NSDate date]];
    return dateCmp.year == dateNow.year;
}

//判断是否是昨天
- (BOOL)isYesterday
{
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd";
    NSString *date = [formatter stringFromDate:self];
    NSString *nowDate = [formatter stringFromDate:[NSDate date]];
    //把字符串转成时间
    NSDate *date1 = [formatter dateFromString:date];
    NSDate *nowDate1 = [formatter dateFromString:nowDate];
    NSCalendarUnit unit = NSCalendarUnitYear | NSCalendarUnitMonth |NSCalendarUnitDay;
    NSDateComponents *dateCmp = [calendar components:unit fromDate:date1 toDate:nowDate1 options:0];
    return dateCmp.year==0 && dateCmp.month==0 && dateCmp.day==1;
}

//判断是否是今天
- (BOOL)isToday
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd";
    NSString *date = [formatter stringFromDate:self];
    NSString *nowDate = [formatter stringFromDate:[NSDate date]];
    return [date isEqualToString:nowDate];
}



@end


