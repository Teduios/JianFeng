//
//  newFeatureViewController.m
//  weibo
//
//  Created by apple-jd37 on 15/10/31.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "newFeatureViewController.h"
#import "MyHomeTabBarViewController.h"
#define IMAGECOUNT 4

@interface newFeatureViewController () <UIScrollViewDelegate>
@property (nonatomic,strong) UIPageControl  *pageControl;
@property (nonatomic,strong) UIImageView  *imageView;
@end

@implementation newFeatureViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setImage];
}

- (void)setImage
{
    //设置scrollView
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    scrollView.delegate = self;
    scrollView.bounces = NO;
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.pagingEnabled = YES;
    scrollView.contentSize = CGSizeMake(viewWidth*IMAGECOUNT, viewHeight);
    [self.view addSubview:scrollView];
    
    //设置ImageView
    for (int i=0; i<IMAGECOUNT; i++) {
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(i*scrollView.width, 0, scrollView.width, scrollView.height)];
        self.imageView = imageView;
        
        NSString *imageName = [NSString stringWithFormat:@"new_feature_%d",i+1];
        imageView.image = [UIImage imageNamed:imageName];
        
//        NSString *image = [NSString stringWithFormat:@"new_feature_%d@2x.png",i+1];
//
//        NSString *imageName = [[NSBundle mainBundle] pathForResource:image ofType:nil];
//        
//        imageView.image = [UIImage imageWithContentsOfFile: imageName];
        
        [scrollView addSubview:imageView];
        if (i == IMAGECOUNT-1) {
            [self addButton];
        }
    }
    
    UIPageControl *pageControl = [[UIPageControl alloc] init];
    pageControl.frame = CGRectMake(0, 0.88*viewHeight, viewWidth, 40);
    pageControl.numberOfPages = IMAGECOUNT;
    pageControl.currentPageIndicatorTintColor = [UIColor redColor];
    pageControl.pageIndicatorTintColor = [UIColor blackColor];
    pageControl.userInteractionEnabled = NO;
    self.pageControl = pageControl;
    [self.view addSubview:pageControl];
    
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat index = scrollView.contentOffset.x/viewWidth;
    self.pageControl.currentPage = round(index);
}

- (void)addButton
{
    //开启用户交互功能
    self.imageView.userInteractionEnabled = YES;
    UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake((viewWidth-200)/2, 0.7*viewHeight, 200, 80)];
    button.backgroundColor = SetColor(200, 58, 154);
    [button setTitle:@"进入我的微博" forState:UIControlStateNormal];
    [button setTitleColor:SetColor(100, 158, 154) forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:30 weight:5];
    [button setTitleColor:[UIColor redColor] forState:UIControlStateSelected];
    [button setTitleShadowColor:[UIColor redColor] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(gotoNext) forControlEvents:UIControlEventTouchUpInside];
    [self.imageView addSubview:button];
}

- (void)gotoNext
{
    //获取系统提供的通知中心对象
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    NSDictionary *isClick = @{@"isDone":@1};
    [center postNotificationName:@"EnterMyHome" object:self userInfo:isClick];
    
    [[NSUserDefaults standardUserDefaults] setValue:@1 forKey:@"isDone"];
    
    NSLog(@"click值已经存入沙盒,%@",isClick[@"isDone"]);
    
    MyHomeTabBarViewController *vc = [[MyHomeTabBarViewController alloc] init];
    [self presentViewController:vc animated:YES completion:nil];
    
}







@end






