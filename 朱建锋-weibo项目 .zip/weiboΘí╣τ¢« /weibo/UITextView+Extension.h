//
//  UITextView+Extension.h
//  weibo
//
//  Created by apple-jd37 on 15/11/20.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextView (Extension)

- (void)insertAttributeText:(NSAttributedString *)text;

@end
