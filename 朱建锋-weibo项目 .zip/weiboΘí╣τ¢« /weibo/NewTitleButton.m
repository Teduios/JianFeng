//
//  NewTitleButton.m
//  weibo
//
//  Created by apple-jd37 on 15/11/3.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "NewTitleButton.h"

@implementation NewTitleButton

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        self.titleLabel.font = [UIFont systemFontOfSize:16];
        [self  setImage:[UIImage imageNamed:@"navigationbar_arrow_down"] forState:UIControlStateNormal];
        [self setImage:[UIImage imageNamed:@"navigationbar_arrow_up"] forState:UIControlStateSelected];
//        self.backgroundColor = [UIColor redColor];

    }
    return self;
    
}

- (void)setFrame:(CGRect)frame
{
    frame.size.width= 160;
    self.centerX = [UIScreen mainScreen].bounds.size.width/2;
    [super setFrame:frame];
    
}
- (void)layoutSubviews
{
    [super layoutSubviews];
    //计算Button中title位置
    self.titleLabel.x = self.imageView.x;
    self.imageView.x = CGRectGetMaxX(self.titleLabel.frame) + buttonMargin;
   
}

- (void)setTitle:(NSString *)title forState:(UIControlState)state
{
    [super setTitle:title forState:state];
    //让按钮重新自己计算尺寸
    [self sizeToFit];
}

- (void)setImage:(UIImage *)image forState:(UIControlState)state
{
    [super setImage:image forState:state];
    //让图片重新自己计算尺寸
    [self sizeToFit];
}





@end





