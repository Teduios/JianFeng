//
//  MyHomeTabBarViewController.m
//  我的微博项目
//
//  Created by apple-jd37 on 15/10/17.
//  Copyright (c) 2015年 apple-jd37. All rights reserved.
//

#import "MyHomeTabBarViewController.h"
#import "HomeViewController.h"
#import "MessageViewController.h"
#import "DiscoverViewController.h"
#import "PersonalViewController.h"
#import "AddViewController.h"
#import "tabBar.h"
#import "Oauth_Account.h"

#define SetRandomColor SetColor(arc4random_uniform(256), arc4random_uniform(256), arc4random_uniform(256))
@interface MyHomeTabBarViewController () <tabBarDelegate,UITabBarControllerDelegate>

@end

@implementation MyHomeTabBarViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    self.delegate= self;
    
    HomeViewController *homeVC = [[HomeViewController alloc] init];
    homeVC.view.backgroundColor= [UIColor colorWithRed:240/255.0 green:240/255.0 blue:240/255.0 alpha:1];
    homeVC.tabBarItem.tag = 1;
    [self addChildVC:homeVC andTitle:@"首页" andImage:@"tabbar_home" andSelectedImage:@"tabbar_home_highlighted"];
   
    MessageViewController  *messageVC = [[MessageViewController alloc] init];
    messageVC.view.backgroundColor= [UIColor colorWithRed:240/255.0 green:240/255.0 blue:240/255.0 alpha:1];
    [self addChildVC:messageVC andTitle:@"消息" andImage:@"tabbar_message_center" andSelectedImage:@"tabbar_message_center_selected"];
    
    DiscoverViewController *discoverVC = [[DiscoverViewController alloc] initWithStyle:UITableViewStyleGrouped];
    
    [self addChildVC:discoverVC andTitle:@"发现" andImage:@"tabbar_discover" andSelectedImage:@"tabbar_discover_selected"];
    
    PersonalViewController *personalVC = [[PersonalViewController alloc] init];
    personalVC.view.backgroundColor= [UIColor colorWithRed:240/255.0 green:240/255.0 blue:240/255.0 alpha:1];
    [self addChildVC:personalVC andTitle:@"我" andImage:@"tabbar_profile" andSelectedImage:@"tabbar_profile_selected"];
    
    tabBar *bar = [[tabBar alloc] init];
    bar.translucent = NO;
    [self setValue:bar forKey:@"tabBar"];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)tabBarDidClickPlusButton{
    AddViewController *vc = [[AddViewController alloc]init];
    UINavigationController *navi = [[UINavigationController alloc] initWithRootViewController:vc];
    [self presentViewController:navi animated:YES completion:nil];
}


- (void)addChildVC:(UIViewController *)childVc andTitle:(NSString *)title andImage:(NSString *)image andSelectedImage:(NSString *)selectedImage
{
    //设置tabBar控制器的文本和图片
//    childVc.view.backgroundColor = SetRandomColor;
    childVc.tabBarItem.title = title;
    childVc.tabBarItem.image = [UIImage imageNamed:image];
    childVc.tabBarItem.selectedImage = [[UIImage imageNamed:selectedImage] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    //设置tabBar控制器的文本的样式
    NSMutableDictionary *textAttributes = [NSMutableDictionary dictionary];
    textAttributes[NSForegroundColorAttributeName] = SetColor(123, 123, 123);
    NSMutableDictionary *seletedTextAttributes = [NSMutableDictionary dictionary];
    seletedTextAttributes[NSForegroundColorAttributeName] = [UIColor orangeColor];
    
    [childVc.tabBarItem setTitleTextAttributes:textAttributes forState:UIControlStateNormal];
    [childVc.tabBarItem setTitleTextAttributes:seletedTextAttributes forState:UIControlStateSelected];
    UINavigationController *navi = [[UINavigationController alloc] initWithRootViewController:childVc];
    
    [navi.navigationBar setTranslucent:UIBarStyleDefault];
    [self addChildViewController:navi]; 
}

#pragma mark - UITabBarControllerDelegate
- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController
{
    Oauth_Account *acount = [NSKeyedUnarchiver unarchiveObjectWithFile:AccountPath];
    if (!acount.recordMark) {
        return;
    }
    if (viewController.tabBarItem.tag==1)
    {      UINavigationController *navigation =(UINavigationController *)viewController;
        HomeViewController *notice=(HomeViewController *)navigation.topViewController;
        [notice refreshTableView];
         NSLog(@"didSelectViewController");
    }

}

@end













