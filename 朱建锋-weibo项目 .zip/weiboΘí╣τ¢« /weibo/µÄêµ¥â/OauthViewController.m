//
//  OauthViewController.m
//  weibo
//
//  Created by apple-jd37 on 15/10/30.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "OauthViewController.h"
#import "MBProgressHUD+MJ.h"
#import "Oauth_Account.h"
#import "MyHomeTabBarViewController.h"
#import "PersonMessage.h"

@interface OauthViewController () <UIWebViewDelegate>

@end

@implementation OauthViewController
/**
 *  App Key：2077690912
    App Secret：451cba477c966db8d5ffe3912655ba91
 */
- (void)viewDidLoad {
    [super viewDidLoad];
    //https://api.weibo.com/oauth2/authorize
    UIWebView *webView = [[UIWebView alloc] initWithFrame:self.view.bounds];
    webView.delegate = self;
    NSString *path = @"https://api.weibo.com/oauth2/authorize?client_id=2077690912&redirect_uri=http://www.baidu.com";
    NSURL *url = [NSURL URLWithString:path];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [webView loadRequest:request];
    [self.view addSubview:webView];
}

- (void)webViewDidStartLoad:(UIWebView *)webView
{
    ZJFLog(@"webStartLoad");
//    [MBProgressHUD showMessage:@"小哥正在拼命加载"];
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    ZJFLog(@"webFinishLoad");
    [MBProgressHUD hideHUD];
     [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(nullable NSError *)error
{
    ZJFLog(@"webFailLoad %@",error);
    [MBProgressHUD hideHUD];
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    NSString *url = request.URL.absoluteString;
     NSLog(@"回掉地址 %@",url);
    //回掉地址 http://www.baidu.com/?code=0eef7982d039d31a17490a18f9426462
    NSRange range = [url rangeOfString:@"code="];
    if (range.length!=0) {
        //如果已经返回回掉地址了
        int index = range.location+range.length; //返回conde＝后面第一个字母，即获得想要的值
        NSString *code = [url substringFromIndex:index];
         NSLog(@"%@",code);
        [self accessoryToKen:code];
    }
    return YES;
}
   //利用code获取accessToken
- (void)accessoryToKen:(NSString *)code
{
    //https://api.weibo.com/oauth2/access_token
    /**
     client_id        string	申请应用时分配的AppKey。
     client_secret		string	申请应用时分配的AppSecret。
     grant_type		   string	请求的类型，填写authorization_code
     code             string	调用authorize获得的code值。
     redirect_uri		   string	回调地址，需需与注册应用里的回调地址一致。
     */
    
    

        //设置网络管理者
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
        parameters[@"client_id"] = @"2077690912";
        parameters[@"client_secret"] = @"451cba477c966db8d5ffe3912655ba91";
        parameters[@"grant_type"] = @"authorization_code";
        parameters[@"code"] = code;
        parameters[@"redirect_uri"] = @"http://www.baidu.com";
        
        // AFN的AFJSONResponseSerializer默认不接受text/plain这种类型
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/html",@"application/json", @"text/plain",nil];
        
        [manager POST:@"https:api.weibo.com/oauth2/access_token" parameters:parameters success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
            ZJFLog(@"请求成功 ");
            
            [MBProgressHUD showMessage:@"小哥正在拼命加载"];
            //建立模型来存储网络回掉的字典
            Oauth_Account *acount = [Oauth_Account accessFromDict:responseObject];
            
            
            //把模型存入沙盒中
            [NSKeyedArchiver archiveRootObject:acount toFile:AccountPath];
            
            NSLog(@"%@,%@,%@",acount.access_token,acount.expires_in,acount.uid);
            [self presentViewController:[[MyHomeTabBarViewController alloc] init] animated:YES completion:nil];
            [MBProgressHUD hideHUD];
            return ;
        } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
            
            ZJFLog(@"请求失败 %@",error);
        }];


       /**
     "access_token" = "2.00LLSITCk_mbQCd706f7e5780syNKI";
     "expires_in" = 157679999;
     "remind_in" = 157679999;
     uid = 2262755917;
     */
    //这里调取用户信息
    [self showUserMessage];
    
}

- (void)showUserMessage
{
//    dispatch_queue_t queue = dispatch_queue_create("ConcurrentQueue", DISPATCH_QUEUE_CONCURRENT);
//    dispatch_async(queue, ^{
//        Oauth_Account *acount = [Oauth_Account acounted];
//        NSString *url = @"https://api.weibo.com/2/users/show.json";
//        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
//        NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
//        parameters[@"access_token"] = acount.access_token;
//        parameters[@"uid"] = acount.uid;
//        [manager GET:url parameters:parameters success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
//            [MBProgressHUD showMessage:@"正在登录中"];
//            
//            PersonMessage *message = [PersonMessage accessFromDict:responseObject];
//            [NSKeyedArchiver archiveRootObject:message toFile:PersonMessagePath];
//            NSLog(@"%@,%@,%@",message.profile_image_url,message.Description,message.domain);
//            [MBProgressHUD hideHUD];
//        } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
//            NSLog(@"加载用户个人信息失败");
//        }];
//
//    });
    [NSThread sleepForTimeInterval:1];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.4 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    Oauth_Account *acount = [Oauth_Account acounted];
            NSString *url = @"https://api.weibo.com/2/users/show.json";
            AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
            NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
            parameters[@"access_token"] = acount.access_token;
            parameters[@"uid"] = acount.uid;
            [manager GET:url parameters:parameters success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
                [MBProgressHUD showMessage:@"正在登录中"];
    
                PersonMessage *message = [PersonMessage accessFromDict:responseObject];
                [NSKeyedArchiver archiveRootObject:message toFile:PersonMessagePath];
                NSLog(@"%@,%@,%@",message.profile_image_url,message.Description,message.domain);
                [MBProgressHUD hideHUD];
            } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
                NSLog(@"加载用户个人信息失败");
            }];

    });
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
