//
//  Oauth_Account.h
//  weibo
//
//  Created by apple-jd37 on 15/10/30.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Oauth_Account : NSObject <NSCoding>
/**
 "access_token" = "2.00LLSITCk_mbQCd706f7e5780syNKI";
 "expires_in" = 157679999;
 "remind_in" = 157679999;
 uid = 2262755917;
 */
//创建一个状态，用来记录是否处于登陆状态
@property (nonatomic) NSInteger  recordMark;

@property (nonatomic,strong) NSString  *access_token;
//access_ToKen的可使用时间
@property (nonatomic,strong) NSNumber  *expires_in;

@property (nonatomic,strong) NSString  *uid;
//模型创建时间
@property (nonatomic,strong) NSDate   *create_time;

//用户昵称
@property (nonatomic,strong) NSString  *userName;

+ (instancetype)accessFromDict:(NSDictionary *)dict;
+ (Oauth_Account *)acounted;
+ (void)saveAcount:(Oauth_Account *)acount;
@end
