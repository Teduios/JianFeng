//
//  Oauth_Account.m
//  weibo
//
//  Created by apple-jd37 on 15/10/30.
//  Copyright © 2015年 apple-jd37. All rights reserved.
//

#import "Oauth_Account.h"

@implementation Oauth_Account


//根据从网络上传入成功登陆后的全部信息，存到Oauth_Account模型中
+ (instancetype)accessFromDict:(NSDictionary *)dict
{
    Oauth_Account *acount = [[self alloc] init];
    acount.access_token = dict[@"access_token"];
    acount.expires_in = dict[@"expires_in"];
    acount.uid = dict[@"uid"];
    acount.recordMark = 1;
    acount.create_time = [NSDate date];
    return acount;
}
//从沙盒中解档一个对象
- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super init]) {
        self.access_token = [aDecoder decodeObjectForKey:@"access_token"];
        self.expires_in = [aDecoder decodeObjectForKey:@"expires_in"];
        self.uid = [aDecoder decodeObjectForKey:@"uid"];
        self.create_time = [aDecoder decodeObjectForKey:@"create_time"];
        self.userName = [aDecoder decodeObjectForKey:@"name"];
        self.recordMark = 1;
    }
    return self;
}

//归档进入沙盒
- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:self.access_token forKey:@"access_token"];
    [aCoder encodeObject:self.expires_in forKey:@"expires_in"];
    [aCoder encodeObject:self.uid forKey:@"uid"];
    [aCoder encodeObject:self.create_time forKey:@"create_time"];
    [aCoder encodeObject:self.userName forKey:@"name"];
}

+ (Oauth_Account *)acounted
{
    //从沙盒中取出模型
    Oauth_Account *acount = [NSKeyedUnarchiver unarchiveObjectWithFile:AccountPath];
    //过期的秒数
    long long expires_in = [acount.expires_in longLongValue];
    //获取到过期时的时间
    NSDate *time = [acount.create_time dateByAddingTimeInterval:expires_in];
    //获取当前时间
    NSDate *now = [NSDate date];
    
    NSComparisonResult result = [time compare:now];
    if (result == NSOrderedAscending) {
        return  nil;
    }
    return acount;
    
}

+ (void)saveAcount:(Oauth_Account *)acount
{
    [NSKeyedArchiver archiveRootObject:acount toFile:AccountPath];
}






@end
